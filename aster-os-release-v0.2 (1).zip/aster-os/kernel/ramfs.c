#include "ramfs.h"
static unsigned slen(const char*s){unsigned n=0;while(s&&s[n]&&n<4096)n++;return n;}
static char upper(char c){return (c>='a'&&c<='z')?(char)(c-32):c;}
static int seq(const char*a,const char*b){unsigned i=0;while(a[i]&&b[i]&&upper(a[i])==upper(b[i]))i++;return a[i]==b[i];}
static void cp(char*d,const char*s,unsigned cap){unsigned i=0;while(i+1<cap&&s[i]){d[i]=s[i];i++;}d[i]=0;}
void ramfs_init(RamFs*fs){
    for(unsigned i=0;i<RAMFS_FILES;i++)fs->files[i].used=0;
    ramfs_write(fs,"README.TXT","Aster OS v0.2\nNative x86-64 kernel\nEditable notes and mouse navigation\nThis is a volatile in-memory filesystem.\nData is erased after restart.");
    ramfs_write(fs,"HELLO.TXT","Hello from your independent operating system kernel!");
}
RamFile *ramfs_get(RamFs*fs,const char*name){
    for(unsigned i=0;i<RAMFS_FILES;i++)if(fs->files[i].used&&seq(fs->files[i].name,name))return &fs->files[i];
    return 0;
}
int ramfs_write(RamFs*fs,const char*name,const char*data){
    if(!name||!data||!name[0]||slen(name)>=RAMFS_NAME||slen(data)>=RAMFS_CONTENT)return -1;
    for(unsigned i=0;name[i];i++)if(name[i]=='/'||name[i]=='\\')return -1;
    RamFile*f=ramfs_get(fs,name);
    if(!f){for(unsigned i=0;i<RAMFS_FILES;i++)if(!fs->files[i].used){f=&fs->files[i];break;}}
    if(!f)return -2;
    cp(f->name,name,RAMFS_NAME);cp(f->data,data,RAMFS_CONTENT);f->size=slen(f->data);f->used=1;
    return (int)f->size;
}
int ramfs_remove(RamFs*fs,const char*name){RamFile*f=ramfs_get(fs,name);if(!f)return -1;f->used=0;return 0;}

int ramfs_rename(RamFs*fs,const char*old_name,const char*new_name){
    RamFile*f=ramfs_get(fs,old_name);
    if(!f||!new_name||!new_name[0]||slen(new_name)>=RAMFS_NAME||ramfs_get(fs,new_name))return -1;
    for(unsigned i=0;new_name[i];i++)if(new_name[i]=='/'||new_name[i]=='\\')return -1;
    cp(f->name,new_name,RAMFS_NAME);
    return 0;
}
int ramfs_append(RamFs*fs,const char*name,const char*extra){
    RamFile*f=ramfs_get(fs,name);
    if(!f||!extra)return -1;
    unsigned n=slen(extra);
    if(n >= RAMFS_CONTENT - f->size)return -2;
    cp(f->data+f->size,extra,RAMFS_CONTENT-f->size);
    f->size+=n;
    return (int)f->size;
}
