#ifndef ASTER_RAMFS_H
#define ASTER_RAMFS_H
#include <stdint.h>
#define RAMFS_FILES 12
#define RAMFS_NAME 24
#define RAMFS_CONTENT 768
typedef struct {char name[RAMFS_NAME];char data[RAMFS_CONTENT];uint32_t size;uint8_t used;} RamFile;
typedef struct {RamFile files[RAMFS_FILES];} RamFs;
void ramfs_init(RamFs*fs);
RamFile *ramfs_get(RamFs*fs,const char*name);
int ramfs_write(RamFs*fs,const char*name,const char*data);
int ramfs_remove(RamFs*fs,const char*name);
int ramfs_rename(RamFs*fs,const char*old_name,const char*new_name);
int ramfs_append(RamFs*fs,const char*name,const char*extra);
#endif
