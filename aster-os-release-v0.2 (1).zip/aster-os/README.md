# Aster OS 0.2 — Independent x86-64 OS (experimental)

**This is real bootloader and freestanding-kernel source, not a reskin or HTML mockup. It is NOT a complete desktop OS, NOT verified to boot under actual UEFI firmware, and NOT suitable for a real computer.**

The v0.2 engineering build goes beyond the v0.1 boot image: it includes an experimental graphical UEFI installer limited to disposable VirtualBox guests and a *preinstalled* GPT/FAT32 virtual-disk image. These are structurally tested, but not firmware/VM boot-tested in the available environment.

## Implemented and compiled

- Own relocatable PE32+ UEFI bootloader and x86-64 ELF kernel loader, with exit from UEFI Boot Services.
- Own freestanding x86-64 kernel, IDT and CPU exception handler, legacy PIC/PIT, PS/2 keyboard input and **experimental PS/2 mouse** IRQ12 input.
- Physical conventional-memory page allocator, static small heap, framebuffer renderer, native interactive UI.
- Home, Files, System, Settings, Terminal, and editable Notes screens.
- Keyboard-navigation and mouse-click file manager, note creation/editing, editor `Ctrl+S` RAMFS save, new note, appearance toggle, task navigation.
- RAMFS text-file create/read/write/rename/copy/append/delete through the shell; note content remains **volatile**.
- Experimental graphical UEFI installer: optional, only enabled when VirtualBox CPUID signature is present; scans for a unique unused virtual disk; requires manual `ERASE` confirmation; creates protective MBR + primary/backup GPT, a FAT32 EFI System Partition and writes original EFI loader and kernel files.
- Offline tooling to generate ISO9660/El Torito/FAT12 EFI ISO **and** a sparse 512-MiB GPT/FAT32 boot disk.
- Host-side unit/structural tests, including the **installer's actual GPT/FAT32 writer** exercised against a fake EFI BlockIO protocol.

## Hard limits

The kernel **does not yet** provide protected user-mode processes, a preemptive scheduler, sockets, networking, an SSD/NVMe driver, persistent writable filesystem support, Wi-Fi, Bluetooth, audio, a compositing/multifloating-window desktop, modern GPU acceleration, Windows `.exe` support, verified VirtualBox boot, secure updates, or full installation/recovery UX. The VirtualBox-only installer cannot target your ASUS laptop. **Do not run v0.2 on physical hardware.**

## Build from scratch

Required: `clang`, `ld.lld`, `lld-link`, GNU `make`, C host compiler, `readelf`, Python 3.10+, `sha256sum`.

```sh
make clean
make test
```

This runs host tests, produces:

- `dist/aster-os-0.2-uefi.iso` — ~1.6 MB UEFI/El Torito ISO with *experimental installer* and live kernel.
- `dist/aster-os-0.2-gpt.img` — 512 MiB **sparse** virtual disk with the OS already installed on GPT/FAT32. The image occupies only a small amount of disk space on a sparse-aware filesystem, but its virtual size is 512 MiB.
- `dist/SHA256SUMS`.

`make test` has no external network dependencies. The ISO supports UEFI boot only; it is not legacy BIOS compatible.

## VirtualBox evaluation — ISO installer (NOT independently verified)

**Use a completely new, disposable VM and disk, not a real/host disk or a raw physical disk mapping.**

1. Create a 64-bit `Other/Unknown` VM, 2 CPUs, 2 GiB RAM, and enable **EFI**. Disable Secure Boot for this VM only (unsigned bootloader).
2. Attach `aster-os-0.2-uefi.iso` to its virtual optical drive, and **one new empty virtual hard disk of 512 MiB to 2 GiB**. Keep that disk disconnected from any host physical storage. A 512 MiB virtual VDI is recommended.
3. Boot. In the initial graphical screen, press **I** within four seconds to install, or **L** to boot the live environment. The installer accepts only VirtualBox guests with a particular CPUID vendor signature; some nested/Hyper-V-backed configurations may be rejected.
4. If the installer recognizes exactly one blank disk, it shows a destruction warning. Type uppercase **ERASE** and press Enter to authorize formatting. Otherwise press Esc or wait to cancel. Only the first and last 2 MiB are checked for blank sectors; do not connect any disk that contains data.
5. After the installer reports completion, power off the **test VM**, detach the ISO, and start from the virtual hard disk. The installed boot path is `EFI/BOOT/BOOTX64.EFI` and the root contains `KERNEL.ELF`.
6. If the installed system does not boot, capture the VM log and serial output; see `docs/testing.md`. **An installer success screen is not evidence of an actual post-reboot boot test.**

Alternatively, import the `aster-os-0.2-gpt.img` preinstalled image: convert it to VDI with VirtualBox's `VBoxManage convertfromraw aster-os-0.2-gpt.img aster-os-0.2.vdi --format VDI`, attach VDI as sole test disk, enable EFI and boot. This image is a virtual **test** disk, not a general-purpose OS installation. See `docs/installation.md` for details.

## Usage, if runtime boot works

- Press **1–5** to switch pages; press **6** to start a new editor note; **F1** Home, **F2** Files, **F3** Terminal.
- File Manager: click a filename or use arrows + Enter; **N** creates a new note; **Esc** returns from the editor.
- Editor: type text, Enter for new line, Backspace, **Ctrl+S** saves to RAMFS; save remains temporary and disappears on reboot.
- Terminal: type `help`; examples `ls`, `cat README.TXT`, `write DEMO.TXT Hello`, `cp DEMO.TXT COPY.TXT`, `mv COPY.TXT MOVED.TXT`, `append DEMO.TXT World`, `rm MOVED.TXT`, `edit DEMO.TXT`, `mem`, `ticks`, `about`.
- Settings: press `A` or click to toggle the accent. Mouse support is experimental and requires legacy PS/2 support in the VM.

## Source organization

- `boot/` UEFI loader, ELF parser, guarded experimental installer.
- `kernel/` freestanding kernel, IRQ stubs, framebuffer GUI, RAMFS and input handling.
- `tools/` reproducible offline ISO and GPT/FAT32 disk builders + verifier.
- `tests/` RAMFS tests, binary-format checks, independent disk parser, fake EFI BlockIO installer test.
- `docs/` architecture, installer, test criteria, security, unsupported features, milestones.

## Origin, licensing, reproducibility

The Aster source is MIT-licensed. UEFI protocols, FAT32, GPT, ELF, PE, x86-64 registers and related standards are implemented directly; **this is not an implementation of Wine or Windows APIs**. All tests labeled `PASS` have actually run in the host environment; *none* asserts a VM boot has passed. No code or license is represented as coming from a third-party OS.
