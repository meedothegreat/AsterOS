#!/usr/bin/env python3
"""Independent GPT CRC/FAT32 file extraction verification for Aster disk image."""
from pathlib import Path
import struct, sys, zlib

S=512
def u16(b,o): return struct.unpack_from('<H',b,o)[0]
def u32(b,o): return struct.unpack_from('<I',b,o)[0]
def u64(b,o): return struct.unpack_from('<Q',b,o)[0]

def test(path: Path, boot: Path, kernel: Path):
    with path.open('rb') as f:
        total=path.stat().st_size//S
        def sector(lba,count=1):
            f.seek(lba*S)
            data=f.read(count*S)
            assert len(data)==count*S
            return data
        mbr=sector(0)
        assert mbr[510:512]==b'\x55\xaa' and mbr[450]==0xee
        def check_gpt(lba,expected_other,table):
            h=bytearray(sector(lba))
            assert h[:8]==b'EFI PART' and u32(h,12)==92
            crc=u32(h,16)
            struct.pack_into('<I',h,16,0)
            assert zlib.crc32(h[:92])==crc
            assert u64(h,24)==lba and u64(h,32)==expected_other
            entries=sector(table,32)
            assert zlib.crc32(entries)==u32(h,88)
            return entries
        entries=check_gpt(1,total-1,2)
        assert entries==check_gpt(total-1,1,total-33)
        assert entries[:16]==bytes.fromhex('28732ac11ff8d211ba4b00a0c93ec93b')
        first,last= u64(entries,32),u64(entries,40)
        assert 2048==first and last==total-34
        bpb=sector(first)
        assert bpb[510:512]==b'\x55\xaa' and bpb[82:90]==b'FAT32   '
        assert bpb==sector(first+6)
        spc=bpb[13];reserved=u16(bpb,14);nfat=bpb[16];nsec=u32(bpb,32);fatsz=u32(bpb,36)
        assert spc==8 and nfat==2 and nsec==last-first+1
        assert sector(first+reserved,fatsz)==sector(first+reserved+fatsz,fatsz)
        fat=sector(first+reserved,fatsz)
        data=first+reserved+2*fatsz
        fsinfo=sector(first+1)
        assert u32(fsinfo,0)==0x41615252 and u32(fsinfo,484)==0x61417272
        def chain(c):
            seen=set()
            while 2<=c<0x0ffffff8:
                assert c not in seen
                seen.add(c)
                yield sector(data+(c-2)*spc,spc)
                c=u32(fat,c*4)&0x0fffffff
        def find(dirdata,name):
            wanted=(name.split('.')[0].ljust(8)+(name.split('.')[1] if '.' in name else '').ljust(3)).encode()
            for i in range(0,len(dirdata),32):
                ent=dirdata[i:i+32]
                if ent[0]==0: break
                if ent[:11]==wanted:
                    return ((u16(ent,20)<<16)|u16(ent,26),u32(ent,28))
            raise AssertionError(f'missing {name}')
        def load(cluster, size): return b''.join(chain(cluster))[:size]
        root=b''.join(chain(2))
        efi,_=find(root,'EFI')
        bootdir,_=find(b''.join(chain(efi)),'BOOT')
        bcl,bsz=find(b''.join(chain(bootdir)),'BOOTX64.EFI')
        kcl,ksz=find(root,'KERNEL.ELF')
        assert load(bcl,bsz)==boot.read_bytes()
        assert load(kcl,ksz)==kernel.read_bytes()
        assert bsz>0 and ksz>0
        print('PASS: protective MBR and primary/backup GPT checksums, tables and ESP GUID')
        print('PASS: FAT32 boot/backup, FSInfo, double FAT copies and chain integrity')
        print('PASS: EFI/BOOT/BOOTX64.EFI and KERNEL.ELF exactly match compiled binaries')
        print('NOT TESTED: firmware recognition or boot from raw virtual disk')

if __name__=='__main__':
    test(Path(sys.argv[1]),Path(sys.argv[2]),Path(sys.argv[3]))
