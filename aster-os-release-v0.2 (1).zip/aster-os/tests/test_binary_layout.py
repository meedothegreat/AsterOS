#!/usr/bin/env python3
"""Inspect compiled binary properties without executing firmware."""
from pathlib import Path
import struct
import sys


def check(efi_path: Path, elf_path: Path) -> None:
    efi = efi_path.read_bytes()
    pe = struct.unpack_from('<I', efi, 0x3c)[0]
    assert efi[:2] == b'MZ' and efi[pe:pe + 4] == b'PE\0\0'
    assert struct.unpack_from('<H', efi, pe + 4)[0] == 0x8664
    op = pe + 24
    assert struct.unpack_from('<H', efi, op)[0] == 0x20b
    assert struct.unpack_from('<H', efi, op + 68)[0] == 10
    # PE32+ optional header data directory base at +112, relocation entry index 5.
    reloc_rva, reloc_len = struct.unpack_from('<II', efi, op + 112 + 5 * 8)
    assert reloc_rva > 0 and reloc_len > 0, 'EFI PE lacks base relocations'

    elf = elf_path.read_bytes()
    assert elf[:4] == b'\x7fELF' and elf[4] == 2 and elf[5] == 1
    assert struct.unpack_from('<HH', elf, 16) == (3, 62)
    entry, phoff = struct.unpack_from('<QQ', elf, 24)
    phentsize, phnum = struct.unpack_from('<HH', elf, 54)
    assert phnum > 0 and phentsize == 56 and phoff + phnum * phentsize <= len(elf)
    segments = []
    dynamic = None
    for i in range(phnum):
        t, flags, offset, vaddr, _paddr, filesz, memsz, align = struct.unpack_from('<IIQQQQQQ', elf, phoff + i * phentsize)
        assert offset + filesz <= len(elf)
        if t == 1:
            assert memsz >= filesz and align in (1, 4096)
            segments.append((vaddr, vaddr + memsz, flags))
        if t == 2:
            dynamic = (offset, filesz)
    assert len(segments) >= 2
    assert any(start <= entry < end and flags & 1 for start, end, flags in segments), 'Kernel entry not in executable PT_LOAD'
    assert dynamic is not None
    doff, dlen = dynamic
    dyn = {}
    for i in range(0, dlen, 16):
        key, val = struct.unpack_from('<qQ', elf, doff + i)
        dyn[key] = val
        if key == 0:
            break
    assert dyn[9] == 24 and dyn[8] % 24 == 0
    raddr = dyn[7]
    containing = None
    for i in range(phnum):
        t, _, off, virt, _, filesz, _, _ = struct.unpack_from('<IIQQQQQQ', elf, phoff + i * phentsize)
        if t == 1 and virt <= raddr and raddr + dyn[8] <= virt + filesz:
            containing = off + (raddr - virt)
            break
    assert containing is not None
    count = dyn[8] // 24
    assert count > 0
    for i in range(count):
        target, info, addend = struct.unpack_from('<QQq', elf, containing + i * 24)
        assert info & 0xffffffff == 8 and info >> 32 == 0, 'Unexpected nonrelative relocation'
        assert any(start <= target < end - 7 for start, end, _ in segments), 'Relocation out of bounds'
    print(f'PASS: EFI PE32+ relocatable with base relocation table ({reloc_len} bytes)')
    print(f'PASS: ET_DYN kernel entry in executable PT_LOAD; {count} supported RELATIVE relocations')


if __name__ == '__main__':
    assert len(sys.argv) == 3
    check(Path(sys.argv[1]), Path(sys.argv[2]))
