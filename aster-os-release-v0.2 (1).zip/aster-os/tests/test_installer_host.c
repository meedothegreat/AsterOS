/* The SAME GPT/FAT32 writer used in the UEFI installer, tested via a fake EFI
 * BlockIO protocol operating on a disposable host file. No disks are touched.
 */
#define _POSIX_C_SOURCE 200809L
#include <stdio.h>
#include <stdlib.h>
#include <stdint.h>
#include <string.h>
#include <assert.h>
#include <unistd.h>
#include <sys/types.h>
#include "../boot/install.c"
static FILE *disk;
static uint64_t sectors;
static EFI_STATUS mock_alloc(uint32_t kind,UINTN count,void **out){
    (void)kind;*out=malloc((size_t)count);return *out?0:0x8000000000000009ULL;
}
static EFI_STATUS mock_free(void *buf){free(buf);return 0;}
static EFI_STATUS mock_write(EFI_BLOCK_IO*io,uint32_t media,uint64_t lba,UINTN n,const void*buf){
    assert(media==io->Media->MediaId);assert(n%512==0);assert(lba+n/512<=sectors);
    if(fseeko(disk,(off_t)lba*512,SEEK_SET))return 0x8000000000000007ULL;
    return fwrite(buf,1,(size_t)n,disk)==n?0:0x8000000000000007ULL;
}
static EFI_STATUS mock_flush(EFI_BLOCK_IO*io){(void)io;return fflush(disk)?0x8000000000000007ULL:0;}
static uint8_t*load(const char*name,size_t*out){
    FILE*f=fopen(name,"rb");assert(f);
    assert(fseek(f,0,SEEK_END)==0);long size=ftell(f);assert(size>0);
    rewind(f);uint8_t*data=malloc((size_t)size);assert(data);
    assert(fread(data,1,(size_t)size,f)==(size_t)size);fclose(f);*out=(size_t)size;return data;
}
int main(int argc,char**argv){
    assert(argc==4);sectors=512ULL*2048;
    disk=fopen(argv[3],"wb+");assert(disk);
    assert(ftruncate(fileno(disk),(off_t)sectors*512)==0);
    size_t blen,klen;
    uint8_t*bootfile=load(argv[1],&blen);
    uint8_t*kernel=load(argv[2],&klen);
    EFI_BOOT_SERVICES hostbs={0};hostbs.AllocatePool=mock_alloc;hostbs.FreePool=mock_free;
    bs=&hostbs;
    EFI_BLOCK_IO_MEDIA med={0};med.MediaId=7;med.MediaPresent=1;med.LastBlock=sectors-1;med.BlockSize=512;
    EFI_BLOCK_IO io={0};io.Media=&med;io.WriteBlocks=mock_write;io.FlushBlocks=mock_flush;
    int ok=install_disk(&io,bootfile,blen,kernel,klen);
    free(bootfile);free(kernel);fclose(disk);
    assert(ok);puts("PASS: exact UEFI installer GPT/FAT32 writer completed through fake BlockIO");
    return 0;
}
