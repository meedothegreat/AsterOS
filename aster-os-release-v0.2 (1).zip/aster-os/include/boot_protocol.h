#ifndef ASTER_BOOT_PROTOCOL_H
#define ASTER_BOOT_PROTOCOL_H
#include <stdint.h>
#define ASTER_BOOT_MAGIC UINT64_C(0x4153544552424F54)
#define ASTER_BOOT_VERSION 1
/* Versioned hand-off ABI: physical/identity-mapped pointers at kernel entry. */
typedef struct {
    uint64_t magic;
    uint32_t version;
    uint32_t size;
    uint64_t framebuffer;
    uint32_t width, height, pitch, pixel_format;
    uint64_t memory_map;
    uint64_t memory_map_size;
    uint64_t memory_descriptor_size;
    uint64_t rsdp;
    uint64_t kernel_load_base;
    uint64_t kernel_load_bytes;
} AsterBootInfo;
#endif
