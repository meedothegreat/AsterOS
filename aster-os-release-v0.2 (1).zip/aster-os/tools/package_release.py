#!/usr/bin/env python3
"""Pack Aster 0.2 source and verified offline dev release; no secret keys/blobs."""
from pathlib import Path
import hashlib,json,platform,subprocess,sys,lzma,zipfile
ROOT=Path(__file__).resolve().parent.parent
DIST=ROOT/'dist'
OUT=ROOT.parent
ISO=DIST/'aster-os-0.2-uefi.iso'
DISK=DIST/'aster-os-0.2-gpt.img'
COMPRESSED=DIST/'aster-os-0.2-gpt.img.xz'

def digest(path):
    h=hashlib.sha256()
    with path.open('rb') as f:
        while b:=f.read(1<<20): h.update(b)
    return h.hexdigest()

def cmd_version(command):
    try:
        return subprocess.check_output(command,stderr=subprocess.STDOUT,text=True,timeout=4).splitlines()[0]
    except (OSError,subprocess.SubprocessError):return 'unknown'

print('Compressing virtual disk (raw disk is sparse and 512MiB virtual size)...',flush=True)
with DISK.open('rb') as src, lzma.open(COMPRESSED,'wb',preset=1) as dst:
    while block:=src.read(1<<20):dst.write(block)
release={
  'product':'Aster OS','version':'0.2','release_classification':'experimental development build; incomplete OS',
  'target':'UEFI x86-64; VirtualBox test VM only',
  'build_toolchain':{'clang':cmd_version(['clang','--version']),'lld':cmd_version(['ld.lld','--version']),'python':platform.python_version()},
  'test_evidence':{
    'clean_rebuild':'PASS (executed via make clean and make test)',
    'ELF_PE_layout':'PASS (host structural tests)',
    'ISO_ElTorito_FAT12':'PASS (host structural tests)',
    'GPT_FAT32_preinstalled_disk':'PASS (independent host parser)',
    'UEFI_installer_blockIO_writer':'PASS (host-side fake EFI BlockIO and independent disk parser)',
    'RAMFS_operations':'PASS (host C unit tests)',
    'actual_UEFI_boot':'NOT TESTED',
    'VirtualBox_ISO_boot_and_installed_disk':'NOT TESTED',
    'physical_hardware':'NOT TESTED / NOT SUPPORTED',
    'windows_exe_compatibility':'NOT IMPLEMENTED',
    'protected_userspace':'NOT IMPLEMENTED',
  },
  'artifacts':{},
  'safety':'VM-only; no actual boot verification; do not install on a physical disk or use with raw host disk mappings.'
}
for p in [ISO,DISK,COMPRESSED,ROOT/'build/BOOTX64.EFI',ROOT/'build/KERNEL.ELF']:
    release['artifacts'][str(p.relative_to(ROOT))]={'size_bytes':p.stat().st_size,'sha256':digest(p)}
(DIST/'release-manifest.json').write_text(json.dumps(release,indent=2)+'\n')
source_files=[]
for p in sorted(ROOT.rglob('*')):
    if not p.is_file() or any(seg in p.relative_to(ROOT).parts for seg in ('dist','build','.git','__pycache__')):continue
    source_files.append(p)
source_zip=OUT/'aster-os-source-v0.2.zip'
complete_zip=OUT/'aster-os-release-v0.2.zip'
with zipfile.ZipFile(source_zip,'w',zipfile.ZIP_DEFLATED,6) as z:
    for p in source_files:z.write(p,'aster-os/'+str(p.relative_to(ROOT)))
with zipfile.ZipFile(complete_zip,'w',compression=zipfile.ZIP_DEFLATED,compresslevel=6,allowZip64=True) as z:
    for p in source_files:z.write(p,'aster-os/'+str(p.relative_to(ROOT)))
    for p in (ISO,COMPRESSED,DIST/'release-manifest.json',DIST/'SHA256SUMS',DIST/'host-test-results.log'):
        z.write(p,'aster-os/'+str(p.relative_to(ROOT)))
    for p in (ROOT/'build/BOOTX64.EFI',ROOT/'build/KERNEL.ELF'):
        z.write(p,'aster-os/'+str(p.relative_to(ROOT)))
print('Release:',complete_zip,'bytes',complete_zip.stat().st_size)
print('Source:',source_zip,'bytes',source_zip.stat().st_size)
print('ISO sha256:',release['artifacts']['dist/aster-os-0.2-uefi.iso']['sha256'])
print('Raw img virtual size:',DISK.stat().st_size,'compressed:',COMPRESSED.stat().st_size)
