from pathlib import Path
p=Path(__file__).resolve().parent.parent/'kernel/main.c'
s=p.read_text()
s=s.replace('static uint8_t shifted,screen=0,accent_is_teal=1;', 'static uint8_t shifted,ctrl_down,screen=0,accent_is_teal=1;\nstatic uint8_t mouse_available,mouse_phase,mouse_packet[3],mouse_left;\nstatic int mouse_x=480,mouse_y=360;\nstatic volatile uint8_t mouse_data[256];\nstatic volatile uint32_t mouse_read,mouse_write;\nstatic char editor_name[RAMFS_NAME]="NOTE.TXT";\nstatic char editor_text[RAMFS_CONTENT];\nstatic size_t editor_len;\nstatic uint8_t editor_dirty;\nstatic int file_cursor;')
s=s.replace('static void terminal_launch(void){', '''static void copy_text(char *dst,const char *src,size_t limit){
    size_t i=0;while(i+1<limit && src[i]){dst[i]=src[i];i++;}dst[i]=0;
}
static void open_editor(const char *name){
    RamFile *f=ramfs_get(&fs,name);
    copy_text(editor_name,name,sizeof(editor_name));
    copy_text(editor_text,f?f->data:"",sizeof(editor_text));
    editor_len=0;while(editor_text[editor_len])editor_len++;
    editor_dirty=0;screen=5;repaint=1;
}
static void save_editor(void){
    if(ramfs_write(&fs,editor_name,editor_text)>=0){
        editor_dirty=0;terminal_line("EDITOR: SAVED TO RAMFS (VOLATILE)");
    }else terminal_line("EDITOR: SAVE FAILED (RAMFS FULL)");
    repaint=1;
}
static void terminal_launch(void){''')
s=s.replace('terminal_line("HELP LS CAT WRITE RM MEM ALLOC TICKS CLEAR ABOUT");', 'terminal_line("HELP LS CAT WRITE RM CP MV APPEND EDIT MEM ALLOC TICKS CLEAR ABOUT");')
s=s.replace('    }else if(equals(p,"rm")){', '''    }else if(equals(p,"edit")){
        if(!*args)terminal_line("USAGE: EDIT NAME.TXT");
        else open_editor(args);
    }else if(equals(p,"cp")||equals(p,"mv")){
        char *second=args;while(*second&&*second!=' ')second++;
        if(*second){*second++=0;second=skip_spaces(second);}
        RamFile *f=ramfs_get(&fs,args);
        if(!f||!*second)terminal_line("USAGE: CP/MV SOURCE DEST");
        else if(equals(p,"mv"))terminal_line(ramfs_rename(&fs,args,second)==0?"RENAMED":"RENAME FAILED");
        else terminal_line(ramfs_write(&fs,second,f->data)>=0?"COPIED":"COPY FAILED");
    }else if(equals(p,"append")){
        char *data=args;while(*data&&*data!=' ')data++;
        if(*data){*data++=0;data=skip_spaces(data);}
        terminal_line(*args&&*data&&ramfs_append(&fs,args,data)>=0?"APPENDED":"APPEND FAILED");
    }else if(equals(p,"rm")){''')
s=s.replace('    if(screen!=4)return;\n    if(c==\'\\n\'){', '''    if(screen==5){
        if(c=='\\n'){
            if(editor_len+1<sizeof(editor_text)){
                editor_text[editor_len++]='\\n';editor_text[editor_len]=0;editor_dirty=1;repaint=1;
            }
        }else if(c>=32&&c<127&&editor_len+1<sizeof(editor_text)){
            editor_text[editor_len++]=c;editor_text[editor_len]=0;editor_dirty=1;repaint=1;
        }
        return;
    }
    if(screen!=4)return;
    if(c=='\\n'){''')
s=s.replace("if(screen==4&&input_len){input[--input_len]=0;repaint=1;}","if(screen==4&&input_len){input[--input_len]=0;repaint=1;}\n        if(screen==5&&editor_len){editor_text[--editor_len]=0;editor_dirty=1;repaint=1;}")
s=s.replace('    if(scan==0x2a||scan==0x36){shifted=1;return;}', '''    if(scan==0x1d){ctrl_down=1;return;}
    if(scan==0x9d){ctrl_down=0;return;}
    if(scan==0x2a||scan==0x36){shifted=1;return;}''')
s=s.replace('    if(scan&0x80)return;', '''    if(scan&0x80)return;
    if(screen==5 && ctrl_down && scan==0x1f){save_editor();return;}
    if(screen==5 && scan==0x01){screen=1;repaint=1;return;}
    if(screen==1 && scan==0x1c){
        int num=0;
        for(int i=0;i<RAMFS_FILES;i++)if(fs.files[i].used){
            if(num==file_cursor){open_editor(fs.files[i].name);return;}
            num++;
        }
    }
    if(screen==1 && scan==0x48){if(file_cursor>0)file_cursor--;repaint=1;return;}
    if(screen==1 && scan==0x50){if(file_cursor<RAMFS_FILES-1)file_cursor++;repaint=1;return;}''')
s=s.replace('    if(scan==0x3b){screen=0;repaint=1;return;} /* F1: home from terminal */', '''    if(scan==0x3b){screen=0;repaint=1;return;} /* F1: Home */
    if(scan==0x3c){screen=1;repaint=1;return;} /* F2: Files */
    if(scan==0x3d){screen=4;repaint=1;return;} /* F3: Terminal */
    if(screen==1&&scan==0x31){open_editor("NOTE.TXT");return;} /* N: new/edit note */''')
s=s.replace('DECLARE_ISR(32);DECLARE_ISR(33);','DECLARE_ISR(32);DECLARE_ISR(33);DECLARE_ISR(44);')
s=s.replace('        isr25,isr26,isr27,isr28,isr29,isr30,isr31,isr32,isr33};', '        isr25,isr26,isr27,isr28,isr29,isr30,isr31,isr32,isr33};')
s=s.replace('    for(int i=0;i<34;i++)idt_register(i,handlers[i]);','    for(int i=0;i<34;i++)idt_register(i,handlers[i]);\n    idt_register(44,isr44);')
s=s.replace('    outb(0x21,0xfc);outb(0xa1,0xff);','    outb(0x21,0xf8);outb(0xa1,0xef); /* Keyboard, timer, cascade, PS/2 mouse IRQ12 */')
s=s.replace('void interrupt_dispatch(uint64_t *r){', '''static int ps2_ready(int want_write){
    for(int i=0;i<50000;i++){
        uint8_t status=inb(0x64);
        if(want_write ? !(status&2) : (status&1))return 1;
    }
    return 0;
}
static int ps2_read(void){return ps2_ready(0)?(int)inb(0x60):-1;}
static void ps2_command(uint8_t cmd){if(ps2_ready(1))outb(0x64,cmd);}
static void ps2_data(uint8_t data){if(ps2_ready(1))outb(0x60,data);}
static void ps2_mouse_command(uint8_t cmd){ps2_command(0xd4);ps2_data(cmd);}
static void init_mouse(void){
    /* Only generic PS/2 mice; USB-only and modern laptop touchpads are not supported. */
    ps2_command(0xa8);
    ps2_command(0x20);
    int config=ps2_read();
    if(config<0)return;
    ps2_command(0x60);ps2_data((uint8_t)config|2);
    ps2_mouse_command(0xf6);
    if(ps2_read()!=0xfa)return;
    ps2_mouse_command(0xf4);
    if(ps2_read()!=0xfa)return;
    mouse_available=1;
}
static void gui_click(int x,int y);
static void process_mouse(uint8_t b){
    if(mouse_phase==0 && !(b&8))return;
    if(mouse_phase==0 && (b&0xc0))return;
    mouse_packet[mouse_phase++]=b;
    if(mouse_phase<3)return;
    mouse_phase=0;
    int dx=(int)((int8_t)mouse_packet[1]);
    int dy=(int)((int8_t)mouse_packet[2]);
    mouse_x+=dx;mouse_y-=dy;
    if(mouse_x<0)mouse_x=0;if(mouse_y<0)mouse_y=0;
    if(mouse_x>=(int)boot->width)mouse_x=(int)boot->width-1;
    if(mouse_y>=(int)boot->height)mouse_y=(int)boot->height-1;
    int left=mouse_packet[0]&1;
    if(left && !mouse_left)gui_click(mouse_x,mouse_y);
    mouse_left=left;
    repaint=1;
}
void interrupt_dispatch(uint64_t *r){''')
s=s.replace('    if(vector<32){','''    if(vector==44){
        uint8_t status=inb(0x64);
        if(status&1){
            uint8_t b=inb(0x60);
            if(status&0x20){
                uint32_t next=(mouse_write+1)&255;
                if(next!=mouse_read){mouse_data[mouse_write]=b;mouse_write=next;}
            }
        }
        outb(0xa0,0x20);outb(0x20,0x20);return;
    }
    if(vector<32){''')
s=s.replace('    const char *labels[]={"1 HOME","2 FILES","3 SYSTEM","4 SETTINGS","5 TERMINAL"};','    const char *labels[]={"1 HOME","2 FILES","3 SYSTEM","4 SETTINGS","5 TERMINAL","6 EDITOR"};')
s=s.replace('    for(int i=0;i<5;i++){','    for(int i=0;i<6;i++){')
s=s.replace('    text(23,h-42,"PS/2 INPUT",MUTED,1);','    text(23,h-42,mouse_available?"MOUSE + KEYS":"KEYBOARD",MUTED,1);')
s=s.replace('    text(226,446,"PRESS 2-5 FOR PAGES. F1 RETURNS HOME.",MUTED,1);','    text(226,446,"CLICK SIDEBAR OR PRESS 1-5. F2 FILES.",MUTED,1);')
s=s.replace('    int y=178;\n    for(int i=0;i<RAMFS_FILES;i++)if(fs.files[i].used&&y<(int)boot->height-120){', '''    rect((int)boot->width-194,87,145,41,accent());
    text((int)boot->width-179,102,"NEW NOTE",NAVY,1);
    int y=178,num=0;
    for(int i=0;i<RAMFS_FILES;i++)if(fs.files[i].used&&y<(int)boot->height-120){''')
s=s.replace('        rect(205,y,boot->width-247,53,PANEL);text(221,y+10,fs.files[i].name,WHITE,2);', '''        rect(205,y,boot->width-247,53,num==file_cursor?PANEL2:PANEL);
        text(221,y+10,fs.files[i].name,WHITE,2);
        num++;''')
s=s.replace('    text(210,(int)boot->height-84,"EDIT WITH TERMINAL: WRITE NAME.TXT MESSAGE",accent(),1);','    text(210,(int)boot->height-84,"CLICK FILE / ENTER TO EDIT. N NEW. CTRL+S SAVE.",accent(),1);')
anchor='static void draw(void){'
assert anchor in s
s=s.replace(anchor,'''static void editor_draw(void){
    int w=(int)boot->width,h=(int)boot->height;
    text(205,96,"ASTER TEXT EDITOR",WHITE,2);
    text(205,130,editor_name,accent(),2);
    rect(w-151,98,105,39,accent());text(w-139,110,"SAVE",NAVY,2);
    rect(205,168,w-250,h-261,COLOR(7,13,24));
    int x=219,y=189;
    const int max_x=w-64,max_y=h-122;
    for(size_t i=0;i<editor_len && y+10<max_y;i++){
        char c=editor_text[i];
        if(c=='\\n'){x=219;y+=15;continue;}
        if(x+9>=max_x){x=219;y+=15;}
        if(y+10>=max_y)break;
        char shortstr[2]={c,0};text(x,y,shortstr,WHITE,1);x+=6;
    }
    if(y<max_y)rect(x,y,5,10,accent());
    text(210,h-71,editor_dirty?"UNSAVED - CTRL+S SAVE | ESC FILES":"SAVED - CTRL+S SAVE | ESC FILES",MUTED,1);
    text(210,h-56,"VOLATILE: CONTENT IS LOST ON RESTART",MUTED,1);
}
static void gui_click(int x,int y){
    if(x>=12&&x<170){
        for(int i=0;i<6;i++){
            int yy=105+i*65;
            if(y>=yy-13 && y<yy+32){
                if(i==5){open_editor("NOTE.TXT");return;}
                screen=(uint8_t)i;repaint=1;return;
            }
        }
    }
    if(screen==1){
        if(x>(int)boot->width-194&&x<(int)boot->width-49&&y>=87&&y<=128){open_editor("NOTE.TXT");return;}
        int row_y=178;
        for(int i=0;i<RAMFS_FILES;i++)if(fs.files[i].used){
            if(x>=205&&x<(int)boot->width-42&&y>=row_y&&y<row_y+53){
                open_editor(fs.files[i].name);return;
            }
            row_y+=63;
        }
    }
    if(screen==5&&x>(int)boot->width-151&&x<(int)boot->width-46&&y>=98&&y<=137){save_editor();return;}
    if(screen==3&&x>=225&&x<400&&y>=188&&y<295){accent_is_teal=!accent_is_teal;repaint=1;}
}
static void draw_cursor(void){
    if(!mouse_available)return;
    int x=mouse_x,y=mouse_y;
    rect(x+2,y+2,5,14,NAVY);
    rect(x+1,y+1,3,11,WHITE);
    rect(x+4,y+6,8,3,WHITE);
    rect(x+5,y+10,4,4,WHITE);
}
static void draw(void){''')
s=s.replace('        case 4:screen_terminal();break;\n    }\n}', '        case 4:screen_terminal();break;\n        case 5:editor_draw();break;\n    }\n    draw_cursor();\n}')
s=s.replace('    terminal_launch();init_interrupts();draw();repaint=0;', '''    terminal_launch();init_interrupts();init_mouse();draw();repaint=0;''')
s=s.replace('        while(scan_r!=scan_w){','''        while(mouse_read!=mouse_write){
            uint8_t b=mouse_data[mouse_read];mouse_read=(mouse_read+1)&255;process_mouse(b);
        }
        while(scan_r!=scan_w){''')
s=s.replace('    if(scan>=0x02&&scan<=0x05&&screen!=4){screen=(uint8_t)(scan-0x02);repaint=1;return;}', '    if(scan>=0x02&&scan<=0x05&&screen!=4&&screen!=5){screen=(uint8_t)(scan-0x02);repaint=1;return;}')
s=s.replace('    if(scan==0x06&&screen!=4){screen=4;repaint=1;return;}', '    if(scan==0x06&&screen!=4&&screen!=5){screen=4;repaint=1;return;}')
s=s.replace('    text(w-208,24,"DEVELOPER 0.1",MUTED,1);', '    text(w-208,24,"DEVELOPER 0.2",MUTED,1);')
s=s.replace('    terminal_line("ASTER COMMAND SHELL 0.1");','    terminal_line("ASTER COMMAND SHELL 0.2");')
s=s.replace('"ASTER OS 0.1, INDEPENDENT X86-64 KERNEL"','"ASTER OS 0.2, INDEPENDENT X86-64 KERNEL"')
s=s.replace('"\\r\\nAster OS 0.1: entered native kernel\\r\\n"','"\\r\\nAster OS 0.2: entered native kernel\\r\\n"')
p.write_text(s)
p=Path(__file__).resolve().parent.parent/'kernel/interrupt.S'
s=p.read_text().replace('ISR 33\n','ISR 33\nISR 44\n');p.write_text(s)
