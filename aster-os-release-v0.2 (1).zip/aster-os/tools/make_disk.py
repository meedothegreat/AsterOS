#!/usr/bin/env python3
"""Produce a deterministic, sparse GPT/ESP FAT32 virtual boot disk for Aster OS.

This constructs a *preinstalled test disk*, NOT an on-device installer.
No destination block device is ever opened: only a named output file.
"""
from __future__ import annotations
import os
from pathlib import Path
import struct
import sys
import uuid
import zlib

SECTOR = 512
DEFAULT_MIB = 512
ESP_GUID = uuid.UUID('c12a7328-f81f-11d2-ba4b-00a0c93ec93b')
DISK_GUID = uuid.uuid5(uuid.NAMESPACE_DNS, 'aster-os-dev-disk-v0.2')
PART_GUID = uuid.uuid5(uuid.NAMESPACE_DNS, 'aster-os-esp-v0.2')


def write_sectors(f, lba: int, data: bytes) -> None:
    if len(data) % SECTOR:
        raise ValueError('sector write not aligned')
    f.seek(lba * SECTOR)
    f.write(data)


def write_gpt(f, total: int, start: int, end: int) -> None:
    mbr = bytearray(SECTOR)
    # Protective MBR with single EE partition.
    mbr[446 + 4] = 0xee
    struct.pack_into('<I', mbr, 446 + 8, 1)
    struct.pack_into('<I', mbr, 446 + 12, min(total-1, 0xffffffff))
    mbr[510:512] = b'\x55\xaa'
    write_sectors(f, 0, mbr)
    entries = bytearray(128 * 128)
    entries[0:16] = ESP_GUID.bytes_le
    entries[16:32] = PART_GUID.bytes_le
    struct.pack_into('<QQQ', entries, 32, start, end, 0)
    name = 'Aster EFI'.encode('utf-16le')
    entries[56:56+len(name)] = name
    arr_crc = zlib.crc32(entries)

    def header(here: int, other: int, table_lba: int) -> bytes:
        h = bytearray(SECTOR)
        struct.pack_into('<8sIIIIQQQQ', h, 0, b'EFI PART', 0x10000, 92, 0, 0, here, other, 34, total - 34)
        h[56:72] = DISK_GUID.bytes_le
        struct.pack_into('<QIII', h, 72, table_lba, 128, 128, arr_crc)
        struct.pack_into('<I', h, 16, zlib.crc32(h[:92]))
        return h

    write_sectors(f, 2, entries)
    write_sectors(f, total - 33, entries)
    write_sectors(f, 1, header(1, total-1, 2))
    write_sectors(f, total-1, header(total-1, 1, total-33))


def dirent(name: str, cluster: int, length: int, directory: bool = False) -> bytes:
    if name == '.':
        n = b'.          '
    elif name == '..':
        n = b'..         '
    else:
        parts = name.upper().split('.')
        if not (1 <= len(parts) <= 2 and 1 <= len(parts[0]) <= 8 and
                (len(parts) == 1 or len(parts[1]) <= 3)):
            raise ValueError(f'invalid FAT 8.3 filename {name}')
        n = (parts[0].ljust(8) + (parts[1] if len(parts) > 1 else '').ljust(3)).encode()
    e = bytearray(32)
    e[:11] = n
    e[11] = 0x10 if directory else 0x20
    struct.pack_into('<H', e, 26, cluster & 0xffff)
    struct.pack_into('<H', e, 20, cluster >> 16)
    struct.pack_into('<I', e, 28, length)
    # Fixed repeatable FAT timestamp: Oct 26, 2026 at 12:00.
    struct.pack_into('<HH', e, 22, (12 << 11), ((2026-1980) << 9) | (10 << 5) | 26)
    return bytes(e)


def format_esp(f, start: int, count: int, boot: bytes, kernel: bytes) -> dict:
    sectors_per_cluster = 8
    reserved = 32
    fats = 2
    fat_len = 1
    while True:
        nclusters = (count - reserved - fats * fat_len)//sectors_per_cluster
        needed = (nclusters + 2)*4
        updated = (needed + 511)//512
        if updated == fat_len:
            break
        fat_len = updated
    if nclusters < 65525 or nclusters >= 0x0ffffff0:
        raise ValueError('disk is outside FAT32 cluster bounds')
    data_lba = start + reserved + fats * fat_len
    fat = bytearray(fat_len * SECTOR)
    struct.pack_into('<III', fat, 0, 0x0ffffff8, 0x0fffffff, 0x0fffffff)
    nxt = 3  # root directory allocated cluster 2

    def allocate(content: bytes) -> int:
        nonlocal nxt
        clusters = max(1, (len(content) + 4095)//4096)
        if nxt + clusters > nclusters + 2:
            raise ValueError('not enough FAT32 clusters')
        first = nxt
        for c in range(first, first + clusters):
            struct.pack_into('<I', fat, c * 4, (c + 1) if c < first + clusters - 1 else 0x0fffffff)
        f.seek((data_lba + (first-2) * sectors_per_cluster)*SECTOR)
        f.write(content.ljust(clusters * 4096, b'\0'))
        nxt += clusters
        return first

    dir_efi = allocate(b'')
    dir_boot = allocate(b'')
    file_efi = allocate(boot)
    file_kernel = allocate(kernel)

    def putdir(cluster: int, entries: list[bytes]):
        content = b''.join(entries)
        if len(content) > 4096:
            raise ValueError('directory full')
        write_sectors(f, data_lba + (cluster - 2)*sectors_per_cluster, content.ljust(4096, b'\0'))

    putdir(2, [dirent('EFI', dir_efi, 0, True), dirent('KERNEL.ELF', file_kernel, len(kernel))])
    putdir(dir_efi, [dirent('.', dir_efi, 0, True), dirent('..', 2, 0, True), dirent('BOOT', dir_boot, 0, True)])
    putdir(dir_boot, [dirent('.', dir_boot, 0, True), dirent('..', dir_efi, 0, True), dirent('BOOTX64.EFI', file_efi, len(boot))])
    write_sectors(f, start + reserved, fat)
    write_sectors(f, start + reserved + fat_len, fat)
    bootsector = bytearray(SECTOR)
    bootsector[:3] = b'\xeb\x58\x90'
    bootsector[3:11] = b'ASTER OS'
    struct.pack_into('<HBHBHHBHHHII', bootsector, 11, 512, sectors_per_cluster,
                     reserved, fats, 0, 0, 0xf8, 0, 63, 255, start, count)
    struct.pack_into('<IHHIHH', bootsector, 36, fat_len, 0, 0, 2, 1, 6)
    bootsector[64] = 0x80
    bootsector[66] = 0x29
    struct.pack_into('<I', bootsector, 67, 0xA57E2026)
    bootsector[71:82] = b'ASTER EFI  '
    bootsector[82:90] = b'FAT32   '
    bootsector[510:512] = b'\x55\xaa'
    write_sectors(f, start, bootsector)
    write_sectors(f, start+6, bootsector)
    fsinfo = bytearray(SECTOR)
    struct.pack_into('<I', fsinfo, 0, 0x41615252)
    struct.pack_into('<I', fsinfo, 484, 0x61417272)
    struct.pack_into('<I', fsinfo, 488, nclusters-(nxt-2))
    struct.pack_into('<I', fsinfo, 492, nxt)
    fsinfo[508:512] = b'\x00\x00\x55\xaa'
    write_sectors(f, start+1, fsinfo)
    write_sectors(f, start+7, fsinfo)
    return dict(cluster_count=nclusters, fat_sectors=fat_len, boot_file_bytes=len(boot), kernel_file_bytes=len(kernel))


def create_disk(output: Path, boot: bytes, kernel: bytes, size_mib: int = DEFAULT_MIB) -> dict:
    if size_mib < 512 or size_mib > 2048:
        raise ValueError('supported size range 512–2048 MiB')
    if len(boot) > 8*1024*1024 or len(kernel) > 8*1024*1024:
        raise ValueError('binary unexpectedly large')
    total = size_mib * 2048
    first = 2048
    last = total - 34
    output.parent.mkdir(parents=True, exist_ok=True)
    with output.open('w+b') as f:
        # sparse image - does not write zeroes to the whole disk
        f.truncate(total * SECTOR)
        write_gpt(f, total, first, last)
        info = format_esp(f, first, last-first+1, boot, kernel)
    return dict(size_mib=size_mib, first_lba=first, last_lba=last, **info)


if __name__ == '__main__':
    if len(sys.argv) != 4:
        raise SystemExit('usage: make_disk.py BOOTX64.EFI KERNEL.ELF output.img')
    meta = create_disk(Path(sys.argv[3]), Path(sys.argv[1]).read_bytes(), Path(sys.argv[2]).read_bytes())
    print('Created sparse virtual disk:',sys.argv[3],meta)
