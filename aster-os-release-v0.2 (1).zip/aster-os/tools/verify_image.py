#!/usr/bin/env python3
"""Structural verifier, NOT a claim that the image was booted in a VM."""
from pathlib import Path
import struct
import sys

SECTOR = 2048


def le16(b: bytes, pos: int) -> int:
    return struct.unpack_from('<H', b, pos)[0]


def le32(b: bytes, pos: int) -> int:
    return struct.unpack_from('<I', b, pos)[0]


def fat_file(fat: bytes, path: list[str]) -> bytes:
    bps = le16(fat, 11)
    assert bps == 512 and fat[13] == 1, 'Unexpected FAT BPB'
    reserve, nfats, root_entries, fat_spf = le16(fat, 14), fat[16], le16(fat, 17), le16(fat, 22)
    fat_table = fat[reserve * bps:(reserve + fat_spf) * bps]
    root_start = (reserve + nfats * fat_spf) * bps
    root_bytes = root_entries * 32
    data_start = root_start + root_bytes
    directory = fat[root_start:root_start + root_bytes]

    def chain(start: int) -> bytes:
        out = bytearray()
        cur = start
        seen = set()
        while 2 <= cur < 0xff0:
            assert cur not in seen, 'FAT cluster loop'
            seen.add(cur)
            off = cur + cur // 2
            word = le16(fat_table, off)
            nextcluster = (word >> 4) if cur & 1 else (word & 0xfff)
            offset = data_start + (cur - 2) * bps
            out.extend(fat[offset:offset + bps])
            cur = nextcluster
        return bytes(out)

    for segment in path:
        segment = segment.upper()
        parts = segment.split('.')
        name = (parts[0].ljust(8) + (parts[1] if len(parts) > 1 else '').ljust(3)).encode('ascii')
        for off in range(0, len(directory), 32):
            entry = directory[off:off + 32]
            if entry[:11] == name:
                content = chain(le16(entry, 26))
                if segment == path[-1]:
                    return content[:le32(entry, 28)]
                directory = content
                break
        else:
            raise AssertionError(f'Missing FAT path component: {segment}')
    raise AssertionError('empty path')


def run(iso_path: Path, efi_path: Path, elf_path: Path) -> None:
    iso = iso_path.read_bytes()
    efi = efi_path.read_bytes()
    elf = elf_path.read_bytes()
    assert len(iso) > 1_400_000 and len(iso) % 2048 == 0
    assert iso[16 * SECTOR:16 * SECTOR + 7] == b'\x01CD001\x01', 'Invalid ISO PVD'
    assert iso[17 * SECTOR:17 * SECTOR + 7] == b'\x00CD001\x01', 'Invalid El Torito boot descriptor'
    assert iso[18 * SECTOR:18 * SECTOR + 7] == b'\xffCD001\x01', 'Missing ISO terminator'
    assert le32(iso, 16 * SECTOR + 80) == len(iso) // 2048
    catalog_lba = le32(iso, 17 * SECTOR + 71)
    c = iso[catalog_lba * SECTOR:catalog_lba * SECTOR + 64]
    assert c[0] == 1 and c[1] == 0xef and c[30:32] == b'\x55\xaa'
    assert sum(struct.unpack('<16H', c[:32])) % 65536 == 0, 'Bad El Torito catalog checksum'
    assert c[32] == 0x88 and c[33] == 0, 'Boot entry not bootable or non-emulation'
    fat_lba = le32(c, 40)
    fat_sectors = le16(c, 38)
    assert fat_sectors == 2880, 'Unexpected EFI boot image size'
    fat = iso[fat_lba * SECTOR:fat_lba * SECTOR + fat_sectors * 512]
    assert fat[0] in (0xeb, 0xe9) and fat[510:512] == b'\x55\xaa'
    assert fat_file(fat,['EFI','BOOT','BOOTX64.EFI']) == efi, 'EFI binary in FAT corrupted'
    assert fat_file(fat,['KERNEL.ELF']) == elf, 'Kernel in FAT corrupted'
    assert efi[:2] == b'MZ'
    peoff = le32(efi, 0x3c)
    assert efi[peoff:peoff + 4] == b'PE\0\0'
    assert le16(efi, peoff + 24 + 68) == 10, 'Not a UEFI application PE subsystem'
    assert elf[:4] == b'\x7fELF' and elf[4] == 2
    assert le16(elf, 16) == 3 and le16(elf, 18) == 62, 'Expected ET_DYN x86-64'
    print('PASS: ISO9660 PVD, volume size and descriptor terminator')
    print('PASS: El Torito EFI platform, boot entry and validation checksum')
    print('PASS: FAT12 EFI/BOOT/BOOTX64.EFI matches compiled PE32+ exactly')
    print('PASS: FAT12 /KERNEL.ELF matches compiled ET_DYN x86-64 exactly')
    print('PASS: PE subsystem EFI application; ELF header architecture')
    print('NOT TESTED: firmware execution, VirtualBox/QEMU boot, physical hardware')


if __name__ == '__main__':
    if len(sys.argv) != 4:
        raise SystemExit('usage: verify_image.py image.iso BOOTX64.EFI KERNEL.ELF')
    run(*map(Path, sys.argv[1:]))
