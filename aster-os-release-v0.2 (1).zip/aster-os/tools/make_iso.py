#!/usr/bin/env python3
"""Create an offline UEFI El Torito ISO9660 image with embedded FAT12 EFI media.

No external ISO authoring software or binary blobs required. No BIOS boot support.
This is a simple standards-focused generator for Aster OS's 0.1 development image.
"""
from __future__ import annotations
from pathlib import Path
import struct
import sys

SECTOR = 2048
FAT_SECTOR = 512
FAT_SECTORS = 2880
FAT_SIZE = 9
ROOT_ENTRIES = 224
FAT_CLUSTER = 1
FAT_ROOT_SECTOR = 1 + FAT_SIZE * 2
FAT_DATA_SECTOR = FAT_ROOT_SECTOR + 14
TIMESTAMP = bytes([2026 - 1900, 10, 26, 12, 0, 0, 0])


def directory_entry(name: str, cluster: int, size: int, directory: bool = False) -> bytes:
    entry = bytearray(32)
    if name == '.':
        entry[0:11] = b'.          '
    elif name == '..':
        entry[0:11] = b'..         '
    else:
        parts = name.upper().split('.')
        assert len(parts) <= 2 and len(parts[0]) <= 8 and (len(parts) == 1 or len(parts[1]) <= 3)
        entry[:11] = (parts[0].ljust(8) + (parts[1] if len(parts) == 2 else '').ljust(3)).encode('ascii')
    entry[11] = 0x10 if directory else 0x20
    struct.pack_into('<HH', entry, 22, 0x6000, 0x5D5A)  # deterministic placeholder DOS time/date
    struct.pack_into('<H', entry, 26, cluster)
    struct.pack_into('<I', entry, 28, size)
    return bytes(entry)


def fat12_image(efi_binary: bytes, kernel_binary: bytes) -> bytes:
    disk = bytearray(FAT_SECTORS * FAT_SECTOR)
    boot = disk[:512]
    boot[0:3] = b'\xeb\x3c\x90'
    boot[3:11] = b'ASTER OS'
    struct.pack_into('<HBHBHHBHHHII', boot, 11, 512, 1, 1, 2, 224, 2880, 0xf0, 9, 18, 2, 0, 0)
    boot[36] = 0
    boot[38] = 0x29
    struct.pack_into('<I', boot, 39, 0xA57E2026)
    boot[43:54] = b'ASTER UEFI '
    boot[54:62] = b'FAT12   '
    boot[510:512] = b'\x55\xaa'
    disk[:512] = boot
    fat = bytearray(FAT_SIZE * FAT_SECTOR)
    fat[:3] = b'\xf0\xff\xff'

    def set_next(cluster: int, value: int) -> None:
        assert cluster < 0xff0
        off = cluster + cluster // 2
        if cluster % 2:
            fat[off] = (fat[off] & 0x0f) | ((value & 15) << 4)
            fat[off + 1] = (value >> 4) & 255
        else:
            fat[off] = value & 255
            fat[off + 1] = (fat[off + 1] & 0xf0) | ((value >> 8) & 15)

    nxt = 2

    def clusters_for(payload: bytes) -> int:
        nonlocal nxt
        count = max(1, (len(payload) + 511) // 512)
        first = nxt
        for i in range(count):
            current = nxt
            nxt += 1
            assert nxt < 2848, 'FAT12 image capacity exceeded'
            set_next(current, 0xfff if i == count - 1 else current + 1)
            data_offset = (FAT_DATA_SECTOR + current - 2) * FAT_SECTOR
            disk[data_offset:data_offset + 512] = payload[i * 512:(i + 1) * 512].ljust(512, b'\0')
        return first

    efi_dir_cluster = clusters_for(b'')
    boot_dir_cluster = clusters_for(b'')
    boot_file_cluster = clusters_for(efi_binary)
    kernel_file_cluster = clusters_for(kernel_binary)

    def write_dir(cluster: int, entries: list[bytes]) -> None:
        location = (FAT_DATA_SECTOR + cluster - 2) * 512
        assert len(entries) <= 16
        disk[location:location + len(entries) * 32] = b''.join(entries)

    write_dir(efi_dir_cluster, [
        directory_entry('.', efi_dir_cluster, 0, True),
        directory_entry('..', 0, 0, True),
        directory_entry('BOOT', boot_dir_cluster, 0, True),
    ])
    write_dir(boot_dir_cluster, [
        directory_entry('.', boot_dir_cluster, 0, True),
        directory_entry('..', efi_dir_cluster, 0, True),
        directory_entry('BOOTX64.EFI', boot_file_cluster, len(efi_binary)),
    ])
    root = [
        directory_entry('EFI', efi_dir_cluster, 0, True),
        directory_entry('KERNEL.ELF', kernel_file_cluster, len(kernel_binary)),
    ]
    offset = FAT_ROOT_SECTOR * 512
    disk[offset:offset + len(root) * 32] = b''.join(root)
    disk[512:512 + len(fat)] = fat
    disk[512 + len(fat):512 + 2 * len(fat)] = fat
    return bytes(disk)


def both16(v: int) -> bytes:
    return struct.pack('<H', v) + struct.pack('>H', v)


def both32(v: int) -> bytes:
    return struct.pack('<I', v) + struct.pack('>I', v)


def dirrec(lba: int, size: int, name: bytes, is_dir: bool) -> bytes:
    nlen = len(name)
    out = bytearray(33 + nlen + (not (nlen & 1)))
    out[0] = len(out)
    out[2:10] = both32(lba)
    out[10:18] = both32(size)
    out[18:25] = TIMESTAMP
    out[25] = 2 if is_dir else 0
    out[28:32] = both16(1)
    out[32] = nlen
    out[33:33 + nlen] = name
    return bytes(out)


def create_iso(efi_binary: bytes, kernel_binary: bytes) -> bytes:
    efi_fat = fat12_image(efi_binary, kernel_binary)
    readme = b'ASTER OS 0.2 - UEFI boot + experimental virtual disk installer\r\n'
    readme += b'Enable EFI firmware in VirtualBox. Press I to install on fresh VM disk.\r\n'
    image_records = [
        ('EFI.IMG;1', efi_fat),
        ('README.TXT;1', readme),
        ('KERNEL.ELF;1', kernel_binary),
        ('BOOTX64.EFI;1', efi_binary),
    ]
    catalog_lba = 22
    start_lba = 23
    cursor = start_lba
    files: list[tuple[str, bytes, int]] = []
    for filename, content in image_records:
        files.append((filename, content, cursor))
        cursor += (len(content) + SECTOR - 1) // SECTOR
    total_sectors = cursor + 1
    iso = bytearray(total_sectors * SECTOR)
    pvd = memoryview(iso)[16 * SECTOR:17 * SECTOR]
    pvd[0:7] = b'\1CD001\1'
    pvd[8:40] = b'ASTER DEVELOPMENT'.ljust(32, b' ')
    pvd[40:72] = b'ASTER_OS_02'.ljust(32, b' ')
    pvd[80:88] = both32(total_sectors)
    pvd[120:124] = both16(1)
    pvd[124:128] = both16(1)
    pvd[128:132] = both16(SECTOR)
    pvd[132:140] = both32(10)
    struct.pack_into('<I', pvd, 140, 19)
    struct.pack_into('>I', pvd, 148, 20)
    pvd[156:190] = dirrec(21, SECTOR, b'\x00', True)
    pvd[813:830] = b'2026102612000000\x00'
    pvd[830:847] = b'2026102612000000\x00'
    pvd[847:864] = b'0000000000000000\x00'
    pvd[864:881] = b'0000000000000000\x00'
    pvd[881] = 1
    boot_record = memoryview(iso)[17 * SECTOR:18 * SECTOR]
    boot_record[0:7] = b'\0CD001\1'
    boot_record[7:39] = b'EL TORITO SPECIFICATION'.ljust(32, b' ')
    struct.pack_into('<I', boot_record, 71, catalog_lba)
    iso[18 * SECTOR:18 * SECTOR + 7] = b'\xffCD001\1'
    path_little = struct.pack('<BBIH', 1, 0, 21, 1) + b'\0\0'
    path_big = struct.pack('>BBIH', 1, 0, 21, 1) + b'\0\0'
    iso[19 * SECTOR:19 * SECTOR + len(path_little)] = path_little
    iso[20 * SECTOR:20 * SECTOR + len(path_big)] = path_big
    recs = [dirrec(21, SECTOR, b'\0', True), dirrec(21, SECTOR, b'\1', True)]
    recs += [dirrec(lba, len(data), filename.encode('ascii'), False) for filename, data, lba in files]
    root = b''.join(recs)
    assert len(root) <= SECTOR
    iso[21 * SECTOR:21 * SECTOR + len(root)] = root
    catalog = bytearray(64)
    catalog[0] = 1   # validation header
    catalog[1] = 0xef   # EFI platform ID
    catalog[4:28] = b'ASTER OS UEFI'.ljust(24, b' ')
    catalog[30:32] = b'\x55\xaa'
    checksum = (-sum(struct.unpack('<16H', catalog[:32]))) & 0xffff
    struct.pack_into('<H', catalog, 28, checksum)
    catalog[32] = 0x88  # bootable, no-emulation
    catalog[33] = 0    # no-emulation media
    struct.pack_into('<H', catalog, 38, len(efi_fat) // 512)
    struct.pack_into('<I', catalog, 40, files[0][2])
    iso[catalog_lba * SECTOR:catalog_lba * SECTOR + 64] = catalog
    for filename, data, lba in files:
        iso[lba * SECTOR:lba * SECTOR + len(data)] = data
    return bytes(iso)


def main() -> None:
    if len(sys.argv) != 4:
        raise SystemExit('usage: make_iso.py BOOTX64.EFI KERNEL.ELF output.iso')
    efi = Path(sys.argv[1]).read_bytes()
    kernel = Path(sys.argv[2]).read_bytes()
    iso = create_iso(efi, kernel)
    dest = Path(sys.argv[3])
    dest.parent.mkdir(parents=True, exist_ok=True)
    dest.write_bytes(iso)
    print(f'Created {dest} ({len(iso):,} bytes; UEFI El Torito + FAT12)')


if __name__ == '__main__':
    main()
