# Changelog

## 0.2 — 2026-10-26

- Added separate graphical UEFI installer (`boot/install.c`) with explicit `ERASE` confirmation, VirtualBox-only CPUID restriction, bounded blank test disk check and clean partition formatting to a GPT/FAT32 EFI System Partition.
- Added a self-contained sparse 512-MiB GPT/FAT32 virtual disk-image builder and independent disk-content/CRC verifier.
- Added fake EFI BlockIO host tests exercising **the actual installer formatting code**, not a duplicate algorithm.
- Added optional legacy PS/2 mouse driver via IRQ12 and clickable UI navigation (unverified runtime).
- Added editable text notes and a `Ctrl+S` RAMFS save workflow, filename activation and new-note creation (data is volatile).
- Added RAMFS rename/append functions and shell `cp`, `mv`, `append`, and `edit` commands.
- Added VirtualBox installation guidance and expanded limitations documentation.
- Clean build, PE/ELF/ISO structure, GPT/FAT32, installer-writer and RAMFS host tests passed. Runtime firmware boot remains **not tested**.

## 0.1 — 2026-10-26

- Native UEFI bootloader, freestanding ET_DYN ELF x86-64 kernel, framebuffer UI, PIC/PIT and PS/2 keyboard handler, physical page allocator, RAMFS and terminal.
- Offline UEFI ISO builder, host-side RAMFS tests and structural image validation.
