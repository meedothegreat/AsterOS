# Aster OS architecture decisions (v0.1)

## Kernel architecture

**Selected: modular monolithic kernel**, written in freestanding C and x86-64 assembly, with an intentionally small trusted kernel core. A monolithic kernel gives the simplest initial bring-up for exception handling, memory, and graphics. A microkernel would improve fault isolation once services are mature but adds IPC and driver process implementation before any usable user interface. A hybrid model could provide flexibility but inherits substantial integration complexity. Aster's future driver APIs should remain modular so they can be separated later; such an API is not yet implemented.

## Boot path

```text
UEFI firmware, x86-64
  -> El Torito EFI platform boot catalog on ISO9660
  -> 1.44 MiB embedded FAT12 EFI boot medium
  -> \\EFI\\BOOT\\BOOTX64.EFI (PE32+ EFI application)
  -> reads \\KERNEL.ELF (PIE ELF64 ET_DYN)
  -> validates ELF, allocates pages, copies PT_LOAD, applies R_X86_64_RELATIVE
  -> locates GOP framebuffer and ACPI 2.0 RSDP
  -> acquires UEFI memory map + retries ExitBootServices if map key changes
  -> transfers to SysV ABI kernel entry with versioned AsterBootInfo
  -> native kernel stack, serial, RAMFS, page allocator, IDT/PIC/PIT, UI
```

UEFI's inherited identity-mapped page tables remain in use during milestone 1. Aster **does not yet implement its own page tables**, address-space isolation, permissions, or user mode. Aster does not make EFI boot service calls after successfully leaving UEFI boot services.

## Handoff ABI

`include/boot_protocol.h`: `AsterBootInfo`. Contains magic/version/size, 32-bit GOP geometry and pixel format, 64-bit framebuffer physical address, memory map pointer/size/descriptor size, ACPI RSDP pointer, kernel load address/size. The bootloader is compiled for the Microsoft x64 EFI ABI; kernel entry uses the **System V AMD64 ABI**. The boundary explicitly specifies `sysv_abi`.

## Implemented device support

- Display: UEFI Graphics Output Protocol (GOP), with RGB/BGR pixel format; hardware acceleration unavailable.
- Keyboard: classic virtual i8042 / PS/2 scan code set 1 only (IRQ1); no USB HID or laptop touchpad drivers.
- Timer: 8253/8254 PIT via legacy PIC IRQ0. Not suitable for APIC-only hardware.
- Debugging: COM1 16550 serial output; UI panic screen.
- Memory: EFI conventional memory handoff interpreted as physical frame regions, with monotonic allocation. No freeing/coalescing.
- Storage: none; RAMFS is volatile and **not** a VFS or disk filesystem.

## Near-term next engineering tasks

1. Validate the ISO's firmware boot against actual OVMF/QEMU, then VirtualBox EFI; capture serial output and framebuffer evidence. Fix any protocol/layout/graphics problems exposed by runtime testing.
2. Own page tables and introduce a protected higher-half kernel address space and physical memory bitmap.
3. Add a GDT/TSS, proper interrupt stacks and LAPIC/IOAPIC timing; SMP later.
4. Implement ELF user processes, ring-3 transitions, system calls, a preemptive scheduler and IPC.
5. Add VFS, persistent storage (virtio-blk/AHCI), partition reader, FAT/ext filesystem and disk safety.
6. Add USB HID and modern GPU drivers or a separately documented driver strategy before real laptop testing.

## Dependencies and licensing

The *source of the bootloader and kernel* is project-written C/assembly. Compilers (`clang`, `ld.lld`, `lld-link`), firmware (user's existing VM firmware), and VirtualBox/QEMU used for subsequent testing are third-party components. This repository does not bundle any firmware, drivers, or compatibility layers. Licenses of external tooling remain with their upstream projects.
