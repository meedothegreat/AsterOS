# Security posture and threat model — early development

**There are no production security guarantees.** The image is intended exclusively for isolated VM experimentation. It has no network stack or installer, and therefore cannot intentionally contact remote networks or write persistent disks. Nonetheless, the kernel runs with full privilege; bugs can crash the VM and direct passthrough or misconfiguration would be dangerous.

## Threats and mitigations

- Malformed ELF: loader validates architecture, program header bounds, PT_LOAD segment bounds, and supported relative relocations. It limits kernel file and image size. This is a robustness baseline, not a fuzz-tested ELF parser.
- Unauthorized disk modification: v0.1 has no disk driver, partitioning tool or installer. Future installer must enumerate only target disks and require explicit confirmation before destructive operations.
- Untrusted user input: bounded keyboard ring and RAMFS buffers; shell has basic input size checks. Memory corruption vulnerabilities remain possible.
- Privilege escalation: ring-3 isolation is not yet implemented and every component is privileged. Production user-facing use would be unsafe.
- Update supply chain: no network package manager or update mechanism. No public signing key, private signing key, passwords or hard-coded credentials in the source or generated image.
- Firmware and physical hardware: unsigned EFI artifact; testing should use a disposable VM. No changes to the host UEFI configuration or host bootloader are performed.

Future architecture: isolated userspace; NX/W^X page permissions; enforced privilege checks; trusted EFI Secure Boot chain after signing infrastructure exists; verified update metadata and rollback; entropy and a cryptographically secure RNG; robust authentication and recovery; fuzzing and dynamic testing.
