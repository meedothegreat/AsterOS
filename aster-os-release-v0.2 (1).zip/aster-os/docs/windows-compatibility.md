# Windows application compatibility strategy (future, NOT implemented)

An `.exe`/`.msi` file extension indicates neither that it can run natively nor that it is supported. Wine requires much more than a PE loader: it provides a substantial Win32/NT-facing compatibility API with dependencies on OS facilities like processes, threads, virtual memory, files, signaling/synchronization, audio/video devices and a mature graphics stack.

Aster OS will first need userspace, a working POSIX-like substrate or a separate NT compatibility environment, graphics hardware acceleration or software rendering, package management, and process isolation. Only then would porting a maintained Wine release be feasible. Proton depends on and extends such infrastructure and is not an independent OS compatibility layer. DXVK/vkd3d need Vulkan drivers. Installer support for .msi needs Windows Installer compatibility and registry/prefix handling.

Proposed stages:

1. Native ELF64 applications and a stable native ABI.
2. C runtime, threading and process APIs, filesystem/POSIX capability coverage, loader/runtime dependencies.
3. Wine port and isolated application prefixes with configurable permissions and registry.
4. Desktop app picker and .exe/.msi installers; clear failure reporting for unsupported API features.
5. Optional Vulkan/DirectX translation when GPU drivers permit; document anti-cheat, DRM, proprietary drivers, architecture-specific limitations.
6. Regression suite with documented versions, screenshots/logs and genuinely run pass/fail results.

**Actual Windows .exe/.msi programs successfully tested: 0.**
