# Actual test evidence and reproduction

Build host: Debian GNU/Linux 13 (trixie), x86-64; Clang 17, LLVM lld 17, host C compiler GCC 14, Python 3.

Run `make test` from a fresh checkout. Tests:

1. Cross-compile UEFI loader to PE32+ EFI application (`lld-link`, EFI subsystem 10) — passed.
2. Cross-compile position-independent independent x86-64 kernel ELF (`ld.lld`, `ET_DYN`) — passed.
3. Build ISO9660 with UEFI El Torito catalog pointing to FAT12 EFI image — passed.
4. Verify ISO PVD, volume size, descriptor sequence, boot platform `0xEF`, catalog checksum and boot entry — passed.
5. Read FAT12 directory entries and cluster chains and compare embedded EFI/ELF to compiled originals, byte-for-byte — passed.
6. Host RAMFS unit tests: initial contents, create, case-insensitive read, overwrite, delete, reject invalid/oversized input — passed.
7. VM boot into firmware/OS — **not run**. No QEMU, OVMF or VirtualBox installed in the build environment.
8. Installation into new virtual disk + boot after ISO detached — **not run; installer not implemented**.
9. Wi-Fi, NVMe, USB, audio, laptop OLED/GPU, Windows apps — **not run; required components not implemented**.

Static validation cannot prove actual firmware runtime success. A valid ISO filesystem and boot image still need a runtime compatibility check.
