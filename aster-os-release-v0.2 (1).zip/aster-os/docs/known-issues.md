# Known issues and unsupported features — Aster OS v0.2

## Critical

- **No actual VirtualBox or UEFI boot executed in the build environment.** No QEMU, VirtualBox, or OVMF firmware available here. ISO and disk images pass structural checks only.
- **Installer is experimental:** UEFI installer formatting logic passes a fake BlockIO host test, but no real UEFI BlockIO/GOP installation test has been executed. Use a disposable VM only; it refuses non-VirtualBox guests or unrecognized/ambiguous disks.
- **Only in-memory user data:** RAMFS editor and shell file operations are not persistent and will be erased on restart even when booting from the GPT disk.
- **No ring-3 user-space processes, process loader, paging isolation, scheduler, sockets or IPC.** Built-in apps run as kernel code.
- **No modern laptop hardware support:** AMD Radeon 880M, real NVMe, USB HID, Wi-Fi, Bluetooth, audio, webcam, lid/sleep, battery and thermals not supported.
- **No Windows application compatibility:** no PE app loader, Windows API, Wine, Proton or DirectX translation.
- **No signed/secure boot:** Do not use on any real laptop. Disable Secure Boot only inside the disposable guest if relevant.

## Other limitations

- Legacy PIC/PIT and PS/2 input are not guaranteed even in every VirtualBox configuration; PS/2 mouse initialization and IRQ12 remain unverified.
- UEFI exit assumes existing firmware identity mapping and supported GOP RGB/BGR format. A robust production OS needs its own page tables and APIC/ACPI device model.
- File manager and text editor do not implement scrollback, clipboard, Unicode, directories or persistent saves.
- Installer's blank-disk check only examines the first and last 2 MiB, not every sector. Never attach existing data, raw physical disks or host-backed mappings to the test guest.
- Embedded ELF loader accepts the selected static R_X86_64_RELATIVE relocation class only.
- Not a general installer: no drive choice, resize, filesystem choice, encrypted data, account management, or networking setup.

## First VM diagnostic steps

Obtain VirtualBox `VBox.log`, the EFI firmware text output/screenshot, and optional UART COM1 logging. `kernel_main` writes `Aster OS 0.2: entered native kernel` to COM1 on entry. If no startup, inspect the GOP, EFI file-path handling, and relocation loader. All current tests are host-only.
