# Release acceptance checklist for the next engineering session

This document is a forward test plan, not a completed test report.

## VirtualBox boot QA

- [ ] Verify VirtualBox version, EFI firmware mode, test-only Secure Boot state, RAM and CPU settings.
- [ ] Boot `dist/aster-os-0.1-uefi.iso` directly without writable media.
- [ ] Record firmware discovery of EFI El Torito media and `BOOTX64.EFI` entry.
- [ ] See `Aster OS - EFI loader 0.1` followed by Aster home interface.
- [ ] Navigate screens 1, 2, 3, 4, 5 and F1 using PS/2 keyboard.
- [ ] Confirm timer count increments and UI updates.
- [ ] In terminal run `help`, `ls`, `cat readme.txt`, `write note.txt hello`, `cat note.txt`, `rm note.txt`, `alloc`.
- [ ] Trigger a supported change in resolution and verify display alignment.
- [ ] Record serial logs and note keyboard/mouse and emulated graphics limitations.
- [ ] Attempt cold reboot of VM and confirm RAMFS reset.

## Installer QA (blocked: not implemented)

- [ ] Installer recognizes only chosen VM disk; warning precedes modifications.
- [ ] Cancel before repartition preserves disk contents.
- [ ] GPT/ESP/root filesystem created on disposable disk.
- [ ] Kernel, bootloader and root data copied and verified.
- [ ] Remove ISO and boot directly from the installed VDI.
- [ ] Create user with password; validate first boot and recovery procedure.

## Physical ASUS hardware QA (blocked: not ready)

- [ ] Obtain exact PCI/USB device IDs and firmware details.
- [ ] Back up data and verify a recovery path.
- [ ] Test on removable media without modifying internal disks.
- [ ] Validate display, keyboard, touchpad, storage, wireless, audio, thermals and sleep.

Never mark a test passed without running it and saving its result.
