# Milestones and acceptance criteria — Aster OS

| Stage | Acceptance criteria | Actual v0.2 status |
| --- | --- | --- |
| 1 Architecture/repository | Source, architecture, reproducible build, tests and docs | **Pass** |
| 2 Bootable kernel | UEFI image, native kernel and verified VM runtime boot | **Partial** (compiled + structural tests; VM not boot-tested) |
| 3 Kernel services | Paging isolation, user threads, preemption, syscalls, IPC, VFS/storage | **Incomplete** (frame allocator, IRQ and RAMFS only) |
| 4 User space | Ring-3 processes, executable loader and user libraries | **Not implemented** |
| 5 Graphical desktop | Window manager, multiwindow apps, real file manager/settings | **Partial** (UI, keyboard/mouse input, text editing, RAMFS file operations; no window manager) |
| 6 Installer | Safe install, formatting and first boot | **Partial** (experimental VirtualBox-only graphical UEFI installer and preinstalled disk; host disk-format tests passed, actual boot not tested) |
| 7 HW/VirtualBox | Real hardware IDs and driver validation | **Not complete** (GOP/PS2 only and unverified) |
| 8 Windows compatibility | Wine-like Win32 layer, tested `.exe` support | **Not implemented** |
| 9 Security/polish | Privilege separation, authentication, update signing, recovery | **Not implemented** |
| 10 Release | Full VM install/boot functional test, checksum, installable ISO | **Not met** (checksummed development ISO and virtual disk, without runtime VM proof) |

Aster 0.2 is an engineering artifact, **not** an acceptable substitute for an independently verified, secure desktop OS. Immediate next technical gates: actual UEFI/VirtualBox boot traces; stabilize boot/installer; ring-3 address-space support and syscalls; persistent storage and real VFS; multiwindow compositor; drivers; networking; Win32 compatibility integration; signed updates and recovery.
