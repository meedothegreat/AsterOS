# Aster OS v0.2 installation/testing guide

**This is a high-risk experimental system, restricted to disposable, newly created VirtualBox virtual disks. There is no real-PC installer. Do not pass through host disks to the VM.**

## ISO graphical installer

- Target: VirtualBox 64-bit x86 with EFI, VGA framebuffer GOP support, virtual optical drive and one new 512–2048 MiB disk.
- Start the ISO and press `I` when prompted. A different key or four seconds idle continues live boot.
- Installer checks VirtualBox CPUID hypervisor vendor, identifies EFI BlockIO whole disks, restricts to nonremovable, logical-partition=false, writable, 512-byte block size, aligned I/O supported and correct size.
- A candidate is accepted only if the first and last 2 MiB read back as all zeros; *middle sectors are not exhaustively inspected*, so never attach an existing disk.
- Installer rejects zero or multiple candidates. To proceed, type uppercase **ERASE** followed by Enter.
- Installer constructs a protective MBR, primary and backup GPT with checksums, one EFI System Partition (LBA 2048 to LBA N−34), FAT32 filesystem, `EFI/BOOT/BOOTX64.EFI`, and root `KERNEL.ELF`.
- Press any key at confirmation and let the live system boot; shut down/discard power for the virtual machine, detach the ISO, and boot from the newly formatted virtual disk. Data added to the kernel's RAMFS is still volatile.
- Failures can leave a test virtual disk partially overwritten. **Delete the disposable virtual disk and create a new one** before retrying; never reuse a disk with valuable data.

## Prebuilt disk image (no installer interaction)

The raw disk `dist/aster-os-0.2-gpt.img` already contains a GPT/FAT32 installation. Its total virtual size is 512 MiB; it is a sparse host file, so compression is recommended for transport. To import it:

```sh
# Requires VirtualBox installed on your own machine:
VBoxManage convertfromraw aster-os-0.2-gpt.img aster-os-0.2.vdi --format VDI
```

Create an EFI VM and attach the new VDI as the only hard disk. **Do not attach the raw image as a host disk or overwrite an existing VM disk.**

## System limitations

USB-only input devices, virtual SATA/AHCI access from the kernel, persistent user-file storage, network, updates, multiuser login, NVMe, and installation to physical ASUS laptops are **not implemented**. The installer is graphical but limited to target-check, destructive action confirmation, progress status and success/failure; it does not have language selection, account creation, partition resizing, rollback or a repair interface.

## Verification boundary

Host tests verify the ISO boot catalog and nested EFI FAT12 content, GPT and FAT32 table CRCs and extraction, and also exercise the EFI installer's disk-writer function via a fake BlockIO protocol. They do not emulate UEFI, run VirtualBox, or demonstrate a successful installed-disk boot.
