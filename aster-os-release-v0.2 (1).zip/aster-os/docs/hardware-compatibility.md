# Hardware compatibility report

## Primary future target

ASUS Vivobook S14 M5406WA; user-specified Ryzen AI 9 365, Radeon 880M, 32 GB LPDDR5X, OLED display, UEFI. These are **planning assumptions from the specification, not measurements or hardware identification from the target device**. Exact PCI and USB IDs must be collected on the actual laptop before driver selection.

| Device | Status |
| --- | --- |
| x86-64 AMD CPU | Kernel compiled for x86-64; physical boot untested |
| UEFI boot | EFI application and El Torito FAT image built; runtime untested |
| Native Radeon 880M acceleration | Not implemented |
| Integrated OLED display | UEFI GOP fallback only; native panel/color/scale untested |
| NVMe storage | Not implemented |
| USB-A/USB-C and input controllers | Not implemented |
| Internal laptop keyboard, touchpad | Not implemented; PS/2 virtual keyboard only |
| Wi-Fi and Bluetooth | Not implemented; PCI/USB IDs unknown |
| Speakers, microphones, headphone | Not implemented |
| Battery/ACPI power state/sleep | RSDP passed by loader only; no interpreter or sleep support |
| Thermal management | Not implemented |
| Webcam/external monitors | Not implemented |
| VirtualBox EFI GOP/legacy PS/2 | Implemented in code but not runtime verified |
| Virtual SATA/NVMe disk, network, sound | Not implemented |

This is not a laptop-ready ISO. Before a physical boot, obtain and review firmware and hardware IDs, perform VM acceptance testing, add USB/ACPI/storage drivers, and develop a recovery and rollback path.
