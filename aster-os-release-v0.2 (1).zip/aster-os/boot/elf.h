#ifndef ASTER_ELF_H
#define ASTER_ELF_H
#include <stdint.h>
typedef struct {
    unsigned char ident[16]; uint16_t type,machine; uint32_t version;
    uint64_t entry,phoff,shoff;uint32_t flags;uint16_t ehsize,phentsize,phnum,shentsize,shnum,shstrndx;
} Elf64_Ehdr;
typedef struct {uint32_t type,flags;uint64_t offset,vaddr,paddr,filesz,memsz,align;} Elf64_Phdr;
typedef struct {int64_t tag;uint64_t val;} Elf64_Dyn;
typedef struct {uint64_t offset,info;int64_t addend;} Elf64_Rela;
#define PT_LOAD 1
#define PT_DYNAMIC 2
#define ET_DYN 3
#define EM_X86_64 62
#define DT_NULL 0
#define DT_RELA 7
#define DT_RELASZ 8
#define DT_RELAENT 9
#define R_X86_64_RELATIVE 8
#endif
