#ifndef ASTER_EFI_H
#define ASTER_EFI_H
#include <stdint.h>
typedef uint64_t UINTN;
typedef uint64_t EFI_STATUS;
typedef void *EFI_HANDLE;
typedef uint64_t EFI_PHYSICAL_ADDRESS;
typedef uint16_t CHAR16;
typedef struct {uint32_t a; uint16_t b,c; uint8_t d[8];} EFI_GUID;
#define EFI_ERROR(s) (((s) & 0x8000000000000000ULL)!=0)
#define EFI_SUCCESS 0
#define EFI_BUFFER_TOO_SMALL 0x8000000000000005ULL
#define EFI_INVALID_PARAMETER 0x8000000000000002ULL
#define EFI_NOT_FOUND 0x800000000000000EULL
#define EfiLoaderData 2
#define AllocateAnyPages 0
#define EFI_FILE_MODE_READ 1ULL
typedef struct {uint64_t Signature; uint32_t Revision,HeaderSize,CRC32,Reserved;} EFI_TABLE_HEADER;
typedef struct EFI_SIMPLE_TEXT_OUTPUT_PROTOCOL EFI_SIMPLE_TEXT_OUTPUT_PROTOCOL;
struct EFI_SIMPLE_TEXT_OUTPUT_PROTOCOL {
    void *Reset;
    EFI_STATUS (*OutputString)(EFI_SIMPLE_TEXT_OUTPUT_PROTOCOL*,const CHAR16*);
    void *TestString,*QueryMode,*SetMode,*SetAttribute,*ClearScreen,*SetCursorPosition,*EnableCursor;
    void *Mode;
};
typedef struct EFI_FILE_PROTOCOL EFI_FILE_PROTOCOL;
struct EFI_FILE_PROTOCOL {
    uint64_t Revision;
    EFI_STATUS (*Open)(EFI_FILE_PROTOCOL*,EFI_FILE_PROTOCOL**,const CHAR16*,uint64_t,uint64_t);
    EFI_STATUS (*Close)(EFI_FILE_PROTOCOL*);
    void *Delete;
    EFI_STATUS (*Read)(EFI_FILE_PROTOCOL*,UINTN*,void*);
    void *Write,*GetPosition,*SetPosition,*GetInfo,*SetInfo,*Flush;
};
typedef struct {
    uint64_t Revision;
    EFI_STATUS (*OpenVolume)(void*,EFI_FILE_PROTOCOL**);
} EFI_SIMPLE_FILE_SYSTEM_PROTOCOL;
typedef struct {
    uint32_t Revision;
    EFI_HANDLE ParentHandle;
    void *SystemTable;
    EFI_HANDLE DeviceHandle;
    void *FilePath,*Reserved;
    uint32_t LoadOptionsSize;
    void *LoadOptions,*ImageBase;
    uint64_t ImageSize;
    uint32_t ImageCodeType,ImageDataType;
    void *Unload;
} EFI_LOADED_IMAGE_PROTOCOL;
typedef struct {
    uint32_t Version;
    uint32_t HorizontalResolution,VerticalResolution;
    uint32_t PixelFormat;
    struct {uint32_t RedMask,GreenMask,BlueMask,ReservedMask;} PixelInformation;
    uint32_t PixelsPerScanLine;
} EFI_GRAPHICS_OUTPUT_MODE_INFORMATION;
typedef struct {
    uint32_t MaxMode,Mode;
    EFI_GRAPHICS_OUTPUT_MODE_INFORMATION *Info;
    UINTN SizeOfInfo;
    EFI_PHYSICAL_ADDRESS FrameBufferBase;
    UINTN FrameBufferSize;
} EFI_GRAPHICS_OUTPUT_PROTOCOL_MODE;
typedef struct EFI_GRAPHICS_OUTPUT_PROTOCOL EFI_GRAPHICS_OUTPUT_PROTOCOL;
struct EFI_GRAPHICS_OUTPUT_PROTOCOL {
    EFI_STATUS (*QueryMode)(EFI_GRAPHICS_OUTPUT_PROTOCOL*,uint32_t,UINTN*,EFI_GRAPHICS_OUTPUT_MODE_INFORMATION**);
    EFI_STATUS (*SetMode)(EFI_GRAPHICS_OUTPUT_PROTOCOL*,uint32_t);
    void *Blt;
    EFI_GRAPHICS_OUTPUT_PROTOCOL_MODE *Mode;
};
typedef struct {
    EFI_TABLE_HEADER Hdr;
    void *RaiseTPL,*RestoreTPL;
    EFI_STATUS (*AllocatePages)(uint32_t,uint32_t,UINTN,EFI_PHYSICAL_ADDRESS*);
    EFI_STATUS (*FreePages)(EFI_PHYSICAL_ADDRESS,UINTN);
    EFI_STATUS (*GetMemoryMap)(UINTN*,void*,UINTN*,UINTN*,uint32_t*);
    EFI_STATUS (*AllocatePool)(uint32_t,UINTN,void**);
    EFI_STATUS (*FreePool)(void*);
    void *CreateEvent,*SetTimer,*WaitForEvent,*SignalEvent,*CloseEvent,*CheckEvent;
    void *InstallProtocolInterface,*ReinstallProtocolInterface,*UninstallProtocolInterface;
    EFI_STATUS (*HandleProtocol)(EFI_HANDLE,const EFI_GUID*,void**);
    void *Reserved,*RegisterProtocolNotify,*LocateHandle,*LocateDevicePath,*InstallConfigurationTable;
    void *LoadImage,*StartImage,*Exit,*UnloadImage;
    EFI_STATUS (*ExitBootServices)(EFI_HANDLE,UINTN);
    void *GetNextMonotonicCount,*Stall,*SetWatchdogTimer,*ConnectController,*DisconnectController;
    void *OpenProtocol,*CloseProtocol,*OpenProtocolInformation,*ProtocolsPerHandle,*LocateHandleBuffer;
    EFI_STATUS (*LocateProtocol)(const EFI_GUID*,void*,void**);
    void *InstallMultipleProtocolInterfaces,*UninstallMultipleProtocolInterfaces,*CalculateCrc32,*CopyMem,*SetMem,*CreateEventEx;
} EFI_BOOT_SERVICES;
typedef struct {EFI_GUID VendorGuid;void *VendorTable;} EFI_CONFIGURATION_TABLE;
typedef struct {
    EFI_TABLE_HEADER Hdr;
    CHAR16 *FirmwareVendor;
    uint32_t FirmwareRevision;
    EFI_HANDLE ConsoleInHandle;
    void *ConIn;
    EFI_HANDLE ConsoleOutHandle;
    EFI_SIMPLE_TEXT_OUTPUT_PROTOCOL *ConOut;
    EFI_HANDLE StandardErrorHandle;
    EFI_SIMPLE_TEXT_OUTPUT_PROTOCOL *StdErr;
    void *RuntimeServices;
    EFI_BOOT_SERVICES *BootServices;
    UINTN NumberOfTableEntries;
    EFI_CONFIGURATION_TABLE *ConfigurationTable;
} EFI_SYSTEM_TABLE;
static const EFI_GUID EFI_LOADED_IMAGE_GUID={0x5b1b31a1,0x9562,0x11d2,{0x8e,0x3f,0x00,0xa0,0xc9,0x69,0x72,0x3b}};
static const EFI_GUID EFI_SIMPLE_FS_GUID={0x964e5b22,0x6459,0x11d2,{0x8e,0x39,0x00,0xa0,0xc9,0x69,0x72,0x3b}};
static const EFI_GUID EFI_GOP_GUID={0x9042a9de,0x23dc,0x4a38,{0x96,0xfb,0x7a,0xde,0xd0,0x80,0x51,0x6a}};
static const EFI_GUID EFI_ACPI_20_GUID={0x8868e871,0xe4f1,0x11d3,{0xbc,0x22,0x00,0x80,0xc7,0x3c,0x88,0x81}};
/* EFI ABI sanity checks against the published UEFI 64-bit table layout. */
_Static_assert(__builtin_offsetof(EFI_BOOT_SERVICES, ExitBootServices)==232,"UEFI BootServices layout mismatch");
_Static_assert(__builtin_offsetof(EFI_BOOT_SERVICES, LocateProtocol)==320,"UEFI LocateProtocol layout mismatch");
_Static_assert(__builtin_offsetof(EFI_SYSTEM_TABLE, BootServices)==96,"UEFI SystemTable layout mismatch");
_Static_assert(__builtin_offsetof(EFI_LOADED_IMAGE_PROTOCOL, DeviceHandle)==24,"UEFI loaded-image layout mismatch");
_Static_assert(__builtin_offsetof(EFI_FILE_PROTOCOL, Read)==32,"UEFI file layout mismatch");
#endif
