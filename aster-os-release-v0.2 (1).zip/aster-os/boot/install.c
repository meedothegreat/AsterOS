/* Aster OS experimental graphical UEFI installer.
 * Strictly limited to a disposable virtual machine, zeroed 512-2048 MiB disk,
 * with physical target checks and explicit ERASE confirmation.
 * Reuses only EFI protocols, no external OS/installer code.
 */
#include "efi.h"
#include "font.h"
#include <stdint.h>

#define EBOOT_RED 0
#define EBOOT_GREEN 1
#define EBOOT_BLUE 2
#define C(r,g,b) (((uint32_t)(r)<<16)|((uint32_t)(g)<<8)|(uint32_t)(b))
#define BG C(10,18,31)
#define FG C(231,240,255)
#define ACCENT C(72,212,177)
#define BAD C(255,134,153)
#define EFI_NOT_READY 0x8000000000000006ULL
#define EfiBootServicesData 4

typedef struct {uint16_t ScanCode,UnicodeChar;} EFI_INPUT_KEY;
typedef struct EFI_SIMPLE_TEXT_INPUT EFI_SIMPLE_TEXT_INPUT;
struct EFI_SIMPLE_TEXT_INPUT {
    EFI_STATUS (*Reset)(EFI_SIMPLE_TEXT_INPUT*,uint8_t);
    EFI_STATUS (*ReadKeyStroke)(EFI_SIMPLE_TEXT_INPUT*,EFI_INPUT_KEY*);
    void *WaitForKey;
};
typedef struct {
    uint32_t MediaId;
    uint8_t RemovableMedia,MediaPresent,LogicalPartition,ReadOnly,WriteCaching;
    uint8_t pad[3];
    uint32_t BlockSize,IoAlign;
    uint64_t LastBlock;
} EFI_BLOCK_IO_MEDIA;
typedef struct EFI_BLOCK_IO EFI_BLOCK_IO;
struct EFI_BLOCK_IO {
    uint64_t Revision;
    EFI_BLOCK_IO_MEDIA *Media;
    EFI_STATUS (*Reset)(EFI_BLOCK_IO*,uint8_t);
    EFI_STATUS (*ReadBlocks)(EFI_BLOCK_IO*,uint32_t,uint64_t,UINTN,void*);
    EFI_STATUS (*WriteBlocks)(EFI_BLOCK_IO*,uint32_t,uint64_t,UINTN,const void*);
    EFI_STATUS (*FlushBlocks)(EFI_BLOCK_IO*);
};
_Static_assert(__builtin_offsetof(EFI_BLOCK_IO_MEDIA,LastBlock)==24,"UEFI media layout mismatch");
static const EFI_GUID EFI_BLOCK_IO_GUID = {0x964e5b21,0x6459,0x11d2,{0x8e,0x39,0x00,0xa0,0xc9,0x69,0x72,0x3b}};
static EFI_SYSTEM_TABLE *st;
static EFI_BOOT_SERVICES *bs;
static EFI_GRAPHICS_OUTPUT_PROTOCOL *gp;
static uint32_t width,height,pitch,pixfmt;
static void zmem(void *p,UINTN n){uint8_t*b=p;for(UINTN i=0;i<n;i++)b[i]=0;}
static void cmem(void*d,const void*s,UINTN n){uint8_t*a=d;const uint8_t*b=s;for(UINTN i=0;i<n;i++)a[i]=b[i];}
static void put16(uint8_t*b,uint32_t o,uint16_t v){b[o]=v&255;b[o+1]=(v>>8)&255;}
static void put32(uint8_t*b,uint32_t o,uint32_t v){for(int i=0;i<4;i++)b[o+i]=(uint8_t)(v>>(8*i));}
static void put64(uint8_t*b,uint32_t o,uint64_t v){for(int i=0;i<8;i++)b[o+i]=(uint8_t)(v>>(8*i));}
static uint32_t crc32(const uint8_t*b,UINTN len){
    uint32_t c=0xffffffff;
    for(UINTN i=0;i<len;i++){
        c^=b[i];for(int j=0;j<8;j++)c=(c>>1)^((c&1)?0xedb88320u:0);
    }
    return ~c;
}
static void rect(int x,int y,int w,int h,uint32_t color){
    if(x<0){w+=x;x=0;}if(y<0){h+=y;y=0;}
    if(x>=(int)width||y>=(int)height||w<=0||h<=0)return;
    if(x+w>(int)width)w=(int)width-x;
    if(y+h>(int)height)h=(int)height-y;
    uint32_t r=color>>16,g=(color>>8)&255,b=color&255;
    uint32_t col=pixfmt==0?(b<<16)|(g<<8)|r:(r<<16)|(g<<8)|b;
    volatile uint32_t*fb=(volatile uint32_t*)(UINTN)gp->Mode->FrameBufferBase;
    for(int yy=y;yy<y+h;yy++)for(int xx=x;xx<x+w;xx++)fb[(UINTN)yy*pitch+xx]=col;
}
static void write_line(int x,int y,const char*s,int scale,uint32_t color){
    for(;*s;s++){
        const uint8_t *g=glyph_for(*s);
        for(int i=0;i<7;i++)for(int j=0;j<5;j++)if((g[i]>>(4-j))&1)
            rect(x+j*scale,y+i*scale,scale,scale,color);
        x+=6*scale;
    }
}
static void screen(const char*heading,const char*l1,const char*l2,const char*l3,uint32_t col){
    rect(0,0,width,height,BG);
    rect(0,0,width,65,C(23,37,56));
    rect(35,21,27,27,ACCENT);rect(42,28,13,13,BG);
    write_line(78,24,"ASTER OS INSTALLER",2,FG);
    rect(40,111,width-80,270,C(24,38,58));
    rect(40,111,7,270,col);
    write_line(64,141,heading,2,col);
    write_line(64,208,l1,1,FG);
    write_line(64,239,l2,1,FG);
    write_line(64,270,l3,1,FG);
    write_line(51,height-61,"EXPERIMENTAL: VIRTUALBOX ONLY. NEVER USE A REAL DISK.",1,BAD);
}
static char read_key(uint32_t attempts){
    EFI_SIMPLE_TEXT_INPUT*in=(EFI_SIMPLE_TEXT_INPUT*)st->ConIn;
    if(!in)return 0;
    for(uint32_t i=0;i<attempts;i++){
        EFI_INPUT_KEY key={0,0};
        if(in->ReadKeyStroke(in,&key)==EFI_SUCCESS){
            if(key.UnicodeChar<=127)return (char)key.UnicodeChar;
            if(key.ScanCode==0x17)return 27; /* EFI ESC */
        }
        /* call through typed UEFI firmware pointer, 10 ms per attempt */
        EFI_STATUS (*stall)(UINTN)=(void*)bs->Stall;
        stall(10000);
    }
    return 0;
}
static int virtualbox_only(void){
    uint32_t eax=1,ebx=0,ecx=0,edx=0;
    __asm__ volatile("cpuid":"+a"(eax),"=b"(ebx),"=c"(ecx),"=d"(edx));
    if(!(ecx&(1u<<31)))return 0;
    eax=0x40000000;
    __asm__ volatile("cpuid":"+a"(eax),"=b"(ebx),"=c"(ecx),"=d"(edx));
    /* 'VBoxVBoxVBox' split into EBX, ECX, EDX */
    return ebx==0x786f4256 && ecx==0x786f4256 && edx==0x786f4256;
}
static int sector_zero(EFI_BLOCK_IO*io,uint64_t lba,uint8_t*buf){
    if(EFI_ERROR(io->ReadBlocks(io,io->Media->MediaId,lba,4096,buf)))return 0;
    for(int i=0;i<4096;i++)if(buf[i])return 0;
    return 1;
}
static EFI_BLOCK_IO *find_blank_disk(void){
    UINTN n=0;EFI_HANDLE *handles=0;
    EFI_STATUS (*locate)(uint32_t,const EFI_GUID*,void*,UINTN*,EFI_HANDLE**)=(void*)bs->LocateHandleBuffer;
    if(EFI_ERROR(locate(2,&EFI_BLOCK_IO_GUID,0,&n,&handles)))return 0;
    EFI_BLOCK_IO *candidate=0;
    uint8_t*buffer=0;
    if(EFI_ERROR(bs->AllocatePool(EfiBootServicesData,8192,(void**)&buffer))){bs->FreePool(handles);return 0;}
    /* Align scratch buffer to 4096 bytes for stricter firmware IO requirements. */
    uint8_t *aligned=(uint8_t*)(((UINTN)buffer+4095)&~(UINTN)4095);
    for(UINTN i=0;i<n;i++){
        EFI_BLOCK_IO*io=0;
        if(EFI_ERROR(bs->HandleProtocol(handles[i],&EFI_BLOCK_IO_GUID,(void**)&io))||!io||!io->Media)continue;
        EFI_BLOCK_IO_MEDIA*m=io->Media;
        if(!m->MediaPresent||m->RemovableMedia||m->LogicalPartition||m->ReadOnly||m->BlockSize!=512||m->IoAlign>4096)continue;
        uint64_t total=m->LastBlock+1;
        if(total<512ULL*2048||total>2048ULL*2048)continue;
        /* Only a completely new virtual disk is accepted: blank GPT/MBR/header samples. */
        int clean=1;
        for(uint64_t j=0;j<4096;j+=8){
            if(!sector_zero(io,j,aligned)){clean=0;break;}
        }
        if(!clean)continue;
        for(uint64_t j=total-4096;j<total;j+=8){
            if(!sector_zero(io,j,aligned)){clean=0;break;}
        }
        if(clean){
            if(candidate){candidate=0;break;} /* ambiguous target: refuse */
            candidate=io;
        }
    }
    bs->FreePool(buffer);bs->FreePool(handles);
    return candidate;
}
static int write_blocks(EFI_BLOCK_IO*io,uint64_t lba,const uint8_t*buf,UINTN size){
    return !EFI_ERROR(io->WriteBlocks(io,io->Media->MediaId,lba,size,buf));
}
static void entry(uint8_t*buf,const char*name,uint32_t cluster,uint32_t bytes,int isdir){
    zmem(buf,32);
    uint32_t p=0;while(name[p]&&name[p]!='.'&&p<8){char c=name[p];buf[p]=(uint8_t)(c>='a'&&c<='z'?c-32:c);p++;}
    while(p<8)buf[p++]=' ';
    p=0;while(name[p]&&name[p]!='.')p++;
    if(name[p]=='.')p++;
    for(int k=0;k<3;k++){buf[8+k]=(uint8_t)(name[p]?name[p++]:' ');}
    buf[11]=isdir?0x10:0x20;
    put16(buf,20,cluster>>16);put16(buf,26,cluster&65535);put32(buf,28,bytes);
}
static void dir_dot(uint8_t*b,int parent){
    b[0]='.';for(int i=1;i<11;i++)b[i]=' ';
    if(parent)b[1]='.';
    b[11]=0x10;
}
static int install_disk(EFI_BLOCK_IO*io,const uint8_t*boot,UINTN bootbytes,const uint8_t*kernel,UINTN kernbytes){
    const uint64_t total=io->Media->LastBlock+1,start=2048,last=total-34;
    const uint32_t count=(uint32_t)(last-start+1),reserved=32,spc=8;
    uint32_t fatsz=1,clusters=0;
    for(;;){
        clusters=(count-reserved-2*fatsz)/spc;
        uint32_t required=(clusters+2+127)/128;
        if(required==fatsz)break;
        fatsz=required;
    }
    if(clusters<65525||clusters>=0x0ffffff0u)return 0;
    const uint64_t data=start+reserved+(uint64_t)2*fatsz;
    if((bootbytes+4095)/4096+(kernbytes+4095)/4096+5>=clusters)return 0;
    uint8_t*scratch_raw=0,*table=0,*fat=0;
    if(EFI_ERROR(bs->AllocatePool(EfiBootServicesData,12288,(void**)&scratch_raw)))return 0;
    uint8_t*scratch=(uint8_t*)(((UINTN)scratch_raw+4095)&~(UINTN)4095);
    if(EFI_ERROR(bs->AllocatePool(EfiBootServicesData,16384,(void**)&table))){bs->FreePool(scratch_raw);return 0;}
    if(EFI_ERROR(bs->AllocatePool(EfiBootServicesData,(UINTN)fatsz*512,(void**)&fat))){bs->FreePool(table);bs->FreePool(scratch_raw);return 0;}
    int okay=0;
    zmem(table,16384);zmem(fat,(UINTN)fatsz*512);
    /* GPT partition 1 type: EFI System Partition. Uniquely identified stable development GUIDs. */
    static const uint8_t esp_guid[16]={0x28,0x73,0x2a,0xc1,0x1f,0xf8,0xd2,0x11,0xba,0x4b,0x00,0xa0,0xc9,0x3e,0xc9,0x3b};
    static const uint8_t part_guid[16]={0x98,0x47,0xa0,0x2c,0x6e,0x71,0x50,0x18,0x89,0x10,0xd1,0x83,0xf0,0xc3,0x28,0x42};
    static const uint8_t disk_guid[16]={0x41,0x71,0x53,0xef,0xc3,0x63,0x59,0x39,0xab,0x6f,0x5e,0x80,0x39,0x42,0xc2,0x29};
    cmem(table,esp_guid,16);cmem(table+16,part_guid,16);
    put64(table,32,start);put64(table,40,last);
    const char *label="Aster EFI";for(int i=0;label[i];i++)table[56+i*2]=label[i];
    uint32_t arr_crc=crc32(table,16384);
    /* CRCs are calculated over the first 92 bytes of each GPT header. */
    for(int backup=0;backup<=1;backup++){
        zmem(scratch,4096);
        cmem(scratch,"EFI PART",8);put32(scratch,8,0x10000);put32(scratch,12,92);
        put64(scratch,24,backup?total-1:1);put64(scratch,32,backup?1:total-1);
        put64(scratch,40,34);put64(scratch,48,total-34);
        cmem(scratch+56,disk_guid,16);
        put64(scratch,72,backup?total-33:2);put32(scratch,80,128);put32(scratch,84,128);put32(scratch,88,arr_crc);
        put32(scratch,16,crc32(scratch,92));
        if(!write_blocks(io,backup?total-1:1,scratch,512))goto done;
    }
    for(uint32_t off=0;off<16384;off+=4096){
        cmem(scratch,table+off,4096);
        if(!write_blocks(io,2+off/512,scratch,4096)||
           !write_blocks(io,total-33+off/512,scratch,4096))goto done;
    }
    zmem(scratch,4096);scratch[446+4]=0xee;put32(scratch,446+8,1);
    put32(scratch,446+12,(uint32_t)(total-1));scratch[510]=0x55;scratch[511]=0xaa;
    if(!write_blocks(io,0,scratch,512))goto done;
    /* Root directory cluster 2; EFI and BOOT folders follow. */
    put32(fat,0,0x0ffffff8);put32(fat,4,0x0fffffff);put32(fat,8,0x0fffffff);
    put32(fat,12,0x0fffffff);put32(fat,16,0x0fffffff);
    uint32_t cboot=5, bootclus=(uint32_t)((bootbytes+4095)/4096);
    uint32_t ckernel=cboot+bootclus,kernelclus=(uint32_t)((kernbytes+4095)/4096);
    for(uint32_t c=cboot;c<cboot+bootclus;c++)put32(fat,c*4,c+1==cboot+bootclus?0x0fffffff:c+1);
    for(uint32_t c=ckernel;c<ckernel+kernelclus;c++)put32(fat,c*4,c+1==ckernel+kernelclus?0x0fffffff:c+1);
    /* FAT mirrors: 4 KiB aligned writes. */
    for(int copy=0;copy<2;copy++)for(uint32_t s=0;s<fatsz;s+=8){
        uint32_t ns=(fatsz-s<8)?fatsz-s:8;
        zmem(scratch,4096);cmem(scratch,fat+(UINTN)s*512,ns*512);
        if(!write_blocks(io,start+reserved+copy*(uint64_t)fatsz+s,scratch,ns*512))goto done;
    }
    zmem(scratch,4096);
    entry(scratch,"EFI",3,0,1);entry(scratch+32,"KERNEL.ELF",ckernel,(uint32_t)kernbytes,0);
    if(!write_blocks(io,data,scratch,4096))goto done;
    zmem(scratch,4096);dir_dot(scratch,0);put16(scratch,26,3);
    dir_dot(scratch+32,1);put16(scratch+32,26,2);
    entry(scratch+64,"BOOT",4,0,1);
    if(!write_blocks(io,data+8,scratch,4096))goto done;
    zmem(scratch,4096);dir_dot(scratch,0);put16(scratch,26,4);
    dir_dot(scratch+32,1);put16(scratch+32,26,3);
    entry(scratch+64,"BOOTX64.EFI",cboot,(uint32_t)bootbytes,0);
    if(!write_blocks(io,data+16,scratch,4096))goto done;
    for(uint32_t c=0;c<bootclus;c++){
        zmem(scratch,4096);UINTN off=(UINTN)c*4096;
        UINTN n=bootbytes-off<4096?bootbytes-off:4096;
        cmem(scratch,boot+off,n);
        if(!write_blocks(io,data+(uint64_t)(cboot+c-2)*8,scratch,4096))goto done;
    }
    for(uint32_t c=0;c<kernelclus;c++){
        zmem(scratch,4096);UINTN off=(UINTN)c*4096;
        UINTN n=kernbytes-off<4096?kernbytes-off:4096;
        cmem(scratch,kernel+off,n);
        if(!write_blocks(io,data+(uint64_t)(ckernel+c-2)*8,scratch,4096))goto done;
    }
    /* FAT32 BPB / backup boot sector. */
    zmem(scratch,4096);
    scratch[0]=0xeb;scratch[1]=0x58;scratch[2]=0x90;
    cmem(scratch+3,"ASTER OS",8);
    put16(scratch,11,512);scratch[13]=8;put16(scratch,14,32);scratch[16]=2;
    scratch[21]=0xf8;put16(scratch,24,63);put16(scratch,26,255);
    put32(scratch,28,(uint32_t)start);put32(scratch,32,count);
    put32(scratch,36,fatsz);put32(scratch,44,2);put16(scratch,48,1);put16(scratch,50,6);
    scratch[64]=0x80;scratch[66]=0x29;put32(scratch,67,0xA57E2026);
    cmem(scratch+71,"ASTER EFI  ",11);cmem(scratch+82,"FAT32   ",8);
    scratch[510]=0x55;scratch[511]=0xaa;
    if(!write_blocks(io,start,scratch,512)||!write_blocks(io,start+6,scratch,512))goto done;
    zmem(scratch,4096);put32(scratch,0,0x41615252);put32(scratch,484,0x61417272);
    put32(scratch,488,clusters-(ckernel+kernelclus-2));put32(scratch,492,ckernel+kernelclus);
    scratch[510]=0x55;scratch[511]=0xaa;
    if(!write_blocks(io,start+1,scratch,512)||!write_blocks(io,start+7,scratch,512))goto done;
    if(EFI_ERROR(io->FlushBlocks(io)))goto done;
    okay=1;
done:
    bs->FreePool(fat);bs->FreePool(table);bs->FreePool(scratch_raw);
    return okay;
}

/* Returns after the optional install, so the original live environment can start. */
void install_prompt(EFI_SYSTEM_TABLE *system, EFI_GRAPHICS_OUTPUT_PROTOCOL *gop,
                    const uint8_t *bootfile,UINTN bootlen,const uint8_t*kernel,UINTN klen){
    st=system;bs=st->BootServices;gp=gop;
    if(gp->Mode->Info->PixelFormat>1)return;
    width=gp->Mode->Info->HorizontalResolution;height=gp->Mode->Info->VerticalResolution;
    pitch=gp->Mode->Info->PixelsPerScanLine;pixfmt=gp->Mode->Info->PixelFormat;
    screen("CHOOSE BOOT MODE","PRESS I TO INSTALL TO A BLANK VIRTUAL DISK.",
           "PRESS L OR WAIT 4 SECONDS FOR LIVE SESSION.","NO REAL DISK INSTALLATION IS ALLOWED.",ACCENT);
    char k=read_key(400);
    if(k!='i'&&k!='I')return;
    if(!virtualbox_only()){
        screen("INSTALL BLOCKED","THIS INSTALLER ONLY ALLOWS VIRTUALBOX GUESTS.",
               "NO DISK WAS MODIFIED.","PRESS A KEY TO ENTER LIVE SESSION.",BAD);
        read_key(2000);return;
    }
    screen("SCANNING VIRTUAL DISKS","ONLY ONE NEW 512-2048 MIB DISK IS ALLOWED.",
           "THE FIRST AND LAST 2 MIB MUST BE EMPTY.","CHECKING UEFI BLOCK IO DEVICES...",ACCENT);
    EFI_BLOCK_IO *disk=find_blank_disk();
    if(!disk){
        screen("NO ELIGIBLE DISK","CREATE ONE EMPTY 512 MIB - 2 GIB VIRTUAL DISK.",
               "EXISTING OR AMBIGUOUS DISKS ARE REJECTED.","PRESS A KEY TO ENTER LIVE SESSION.",BAD);
        read_key(2000);return;
    }
    screen("CONFIRM DATA DESTRUCTION","TARGET: ONE EMPTY VIRTUALBOX DISK (512-2048 MIB).",
           "ALL DATA ON THIS VIRTUAL DISK WILL BE ERASED.","TYPE ERASE THEN ENTER. ESC CANCELS.",BAD);
    const char *word="ERASE";int pos=0;
    for(;;){
        k=read_key(3000);
        if(!k||k==27)return;
        if(k=='\r'||k=='\n')break;
        if(k!=word[pos])return;
        pos++;
        if(pos>5)return;
    }
    if(pos!=5)return;
    screen("INSTALLING ASTER OS","CREATING GPT + FAT32 EFI PARTITION...",
           "WRITING BOOTLOADER AND INDEPENDENT KERNEL.","DO NOT TURN OFF THE VIRTUAL MACHINE.",ACCENT);
    int ok=install_disk(disk,bootfile,bootlen,kernel,klen);
    if(ok){
        screen("INSTALLATION COMPLETE","THE VIRTUAL DISK CONTAINS AN EFI BOOT PATH.",
               "REMOVE THE ISO AFTER SHUTDOWN AND REBOOT.","PRESS ANY KEY TO START THE LIVE SESSION.",ACCENT);
    }else{
        screen("INSTALLATION FAILED","A UEFI DISK WRITE OR FORMAT OPERATION FAILED.",
               "THE VIRTUAL DISK MAY BE PARTIALLY MODIFIED.","DELETE THE TEST VIRTUAL DISK AND TRY AGAIN.",BAD);
    }
    read_key(3000);
}
