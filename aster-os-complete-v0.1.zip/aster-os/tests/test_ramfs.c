#include "ramfs.h"
#include <assert.h>
#include <stdio.h>
#include <string.h>
int main(void){
    RamFs fs;
    ramfs_init(&fs);
    assert(ramfs_get(&fs,"README.TXT"));
    assert(ramfs_get(&fs,"readme.txt"));
    assert(!ramfs_get(&fs,"MISSING"));
    assert(ramfs_write(&fs,"NOTE.TXT","test message")==12);
    assert(strcmp(ramfs_get(&fs,"NOTE.TXT")->data,"test message")==0);
    assert(ramfs_write(&fs,"NOTE.TXT","edit")==4);
    assert(strcmp(ramfs_get(&fs,"NOTE.TXT")->data,"edit")==0);
    assert(ramfs_remove(&fs,"NOTE.TXT")==0);
    assert(ramfs_get(&fs,"NOTE.TXT")==0);
    assert(ramfs_write(&fs,"../BAD","oops")<0);
    char long_data[RAMFS_CONTENT+2];memset(long_data,'Z',sizeof(long_data));long_data[sizeof(long_data)-1]=0;
    assert(ramfs_write(&fs,"TOO.TXT",long_data)<0);
    puts("PASS: RAMFS create / overwrite / read / delete / rejection");
    return 0;
}
