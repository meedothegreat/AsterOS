# Aster OS 0.1 — Experimental Independent x86-64 OS

**Status: development image. Not installable, not verified in a VM, not suitable for daily use.**

Aster OS is a small, independent, freestanding x86-64 kernel plus its own UEFI bootloader. It is **not a Linux distribution**, a Windows customization, a webpage, or a virtual machine containing an existing OS. The current milestone is a native framebuffer/keyboard experiment and the foundations for a future desktop OS.

## Included now

- Compiled PE32+ `BOOTX64.EFI` UEFI loader. Reads `KERNEL.ELF` from the EFI FAT volume.
- Relocatable x86-64 ET_DYN ELF kernel and documented handoff structure.
- Exit from UEFI boot services before transferring control to the kernel.
- GOP native framebuffer rendering, an original Aster OS screen layout, 5 pages.
- x86-64 IDT and exception handling, legacy PIC/PIT timer, basic PS/2 IRQ keyboard input.
- Conventional-memory page-frame allocator, small static heap.
- A volatile RAM filesystem with text file create/read/overwrite/delete.
- A built-in terminal: `help`, `ls`, `cat`, `write`, `rm`, `mem`, `alloc`, `ticks`, `clear`, `about`.
- UEFI El Torito ISO9660 image, FAT12 EFI boot image, reproducible offline image generator.
- Host unit tests, format/contents verification, checksum, and a release manifest.

## Quick build

Requirements: GNU Make, Clang 17+, LLVM lld (`ld.lld`, `lld-link`), GCC/Clang for host unit tests, Python 3.10+, `readelf`, and `sha256sum`. No external packages are downloaded by the build.

```sh
make clean
make test
```

Expected output: `dist/aster-os-0.1-uefi.iso` and `dist/SHA256SUMS`. All test output reports a strict distinction between **static structure verification** and **runtime boot verification**.

## Running in VirtualBox (experimental and not verified here)

1. Install VirtualBox on the host computer.
2. Create a **new, disposable** virtual machine named Aster OS. Type: `Other`, version `Other/Unknown (64-bit)` (labels vary by release).
3. Give it at least 2 GB RAM and 2 virtual CPUs; enable **EFI firmware** in the VM settings. If the VM exposes Secure Boot, disable it **for this isolated test VM** because this EFI binary is unsigned.
4. Set the graphics controller to `VBoxSVGA` or `VMSVGA`, with conservative settings and 3D acceleration disabled. GOP is required.
5. Add the supplied ISO to the *virtual optical drive*; do not attach or write to host disks.
6. Start the VM. If the firmware identifies the EFI El Torito boot volume and the bootloader successfully starts, you should see the Aster OS interface, which accepts legacy PS/2 keyboard input.
7. Press `1` Home, `2` Files, `3` System, `4` Settings, or `5` Terminal. Press `F1` to return Home.
8. In Terminal type `help`, `ls`, `cat readme.txt`, `write note.txt hello`, `cat note.txt`. The framebuffer text renderer displays lowercase letters as uppercase.

If the screen is blank or firmware reports no bootable medium, see `docs/known-issues.md`. These steps are **instructions for testing**, not a claim that VirtualBox boot has passed.

**Do not install to an internal disk:** there is no installer or persistent block device driver in v0.1. The ISO never repartitions any disks.

## Source layout

```text
boot/              Custom freestanding UEFI PE/COFF loader and ELF parser
include/           Versioned boot handoff ABI
kernel/            Native kernel, IDT/IRQ stubs, PIT, keyboard, framebuffer, RAMFS
kernel/link.ld     Position-independent kernel link script
tools/             Pure Python FAT12 + EFI El Torito ISO generator, image verification
tests/             RAMFS host unit tests, binary layout tests
docs/              Architecture, implementation status, VM test guide, security and plans
build/             Intermediate binaries (generated)
dist/              Release image, manifest, SHA-256 (generated)
```

## Development roadmap

See `docs/milestones.md` for all ten requested milestones and acceptance criteria. Most are **not complete**. A feature should not be considered supported merely because a similar GUI element appears.

## License / attribution

Aster project's source code is distributed under the MIT License in `LICENSE`. The source tree does not incorporate Linux, EDK2, Wine, proprietary firmware, commercial fonts, or prebuilt drivers. It compiles with the host toolchain, which is not bundled. This license does not guarantee compatibility, security or suitability for any device.
