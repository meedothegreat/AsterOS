# Changelog

## 0.1.0 — 2026-10-26
- Established independent monolithic kernel architecture and versioned EFI boot handoff ABI.
- Added freestanding UEFI loader with relocatable ELF64 loading, GOP and memory map acquisition.
- Implemented basic kernel framebuffer UI, serial output, IDT/exception/IRQ handlers, PIT and PS/2, physical page allocator, RAMFS and shell.
- Added offline FAT12/ISO9660 EFI El Torito image builder, structural verifier, host unit tests and documentation.
- Generated the first experimental ISO and documented unavailable runtime validation.
