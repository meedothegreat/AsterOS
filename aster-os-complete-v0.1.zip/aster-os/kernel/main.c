#include "boot_protocol.h"
#include "ramfs.h"
#include "font.h"
#include <stdint.h>
#include <stddef.h>

#define COLOR(r,g,b) (((uint32_t)(r)<<16)|((uint32_t)(g)<<8)|(uint32_t)(b))
#define NAVY COLOR(11,17,30)
#define PANEL COLOR(21,29,45)
#define PANEL2 COLOR(28,39,59)
#define WHITE COLOR(234,242,252)
#define MUTED COLOR(149,169,193)
static const AsterBootInfo *boot;
static RamFs fs;
static volatile uint64_t ticks;
static volatile uint8_t scans[256];
static volatile uint32_t scan_r,scan_w;
static uint8_t shifted,screen=0,accent_is_teal=1;
static volatile uint32_t repaint=1;
static uint64_t conventional_mib,allocated_frames;
static struct {uint64_t base,next,end;} regions[128];
static uint32_t region_count;
static uint8_t scratch_heap[65536];
static size_t heap_used;
static char term_lines[16][96];
static uint32_t term_next;
static char input[96];
static size_t input_len;

static void outb(uint16_t port,uint8_t value){__asm__ volatile("outb %0,%1"::"a"(value),"Nd"(port));}
static uint8_t inb(uint16_t port){uint8_t v;__asm__ volatile("inb %1,%0":"=a"(v):"Nd"(port));return v;}
static void io_wait(void){outb(0x80,0);}
static void serial_init(void){
    outb(0x3f9,0);outb(0x3fb,0x80);outb(0x3f8,3);outb(0x3f9,0);
    outb(0x3fb,3);outb(0x3fa,0xc7);outb(0x3fc,0x0b);
}
static void serial_str(const char*s){
    for(;*s;s++){
        for(int i=0;i<1000;i++)if(inb(0x3fd)&0x20)break;
        outb(0x3f8,(uint8_t)*s);
    }
}
static int equals(const char*a,const char*b){while(*a&&*b&&*a==*b){a++;b++;}return *a==*b;}
static char *append(char *dst,const char *s){while(*s)*dst++=*s++;*dst=0;return dst;}
static char *uint_to_str(char *dst,uint64_t num){
    char rev[24];int n=0;
    do{rev[n++]=(char)('0'+num%10);num/=10;}while(num&&n<24);
    while(n--)*dst++=rev[n];*dst=0;return dst;
}
static char *hex_to_str(char *dst,uint64_t n){
    const char *digits="0123456789ABCDEF";
    *dst++='0';*dst++='X';
    int leading=1;
    for(int shift=60;shift>=0;shift-=4){int digit=(int)((n>>shift)&15);
        if(digit||shift==0)leading=0;
        if(!leading)*dst++=digits[digit];
    }
    *dst=0;return dst;
}
static void *kalloc(size_t size){
    size=(size+15)&~(size_t)15;
    if(size>sizeof(scratch_heap)-heap_used)return 0;
    void *p=&scratch_heap[heap_used];heap_used+=size;return p;
}
/* The UEFI handoff retains identity-mapped memory; only conventional pages are used. */
static void physical_init(void){
    if(!boot->memory_descriptor_size||boot->memory_descriptor_size<40)return;
    const uint8_t *map=(const uint8_t*)(uintptr_t)boot->memory_map;
    for(uint64_t off=0;off+boot->memory_descriptor_size<=boot->memory_map_size;off+=boot->memory_descriptor_size){
        const uint8_t*p=map+off;
        uint32_t type=*(const uint32_t*)p;
        uint64_t addr=*(const uint64_t*)(p+8),pages=*(const uint64_t*)(p+24);
        if(type!=7||pages==0||addr+pages*4096<addr)continue;
        conventional_mib+=(pages*4096)/1048576;
        if(region_count<128){
            regions[region_count].base=addr;
            regions[region_count].next=addr;
            regions[region_count].end=addr+pages*4096;
            region_count++;
        }
    }
}
static void *physical_alloc_page(void){
    for(uint32_t i=0;i<region_count;i++){
        if(regions[i].next+4096<=regions[i].end){
            uint64_t address=regions[i].next;
            regions[i].next+=4096;
            allocated_frames++;
            return (void*)(uintptr_t)address;
        }
    }
    return 0;
}
static inline uint32_t accent(void){return accent_is_teal?COLOR(68,211,184):COLOR(141,139,255);}
static void rect(int x,int y,int w,int h,uint32_t color){
    if(x<0){w+=x;x=0;}if(y<0){h+=y;y=0;}
    if(w<=0||h<=0||x>=(int)boot->width||y>=(int)boot->height)return;
    if(x+w>(int)boot->width)w=(int)boot->width-x;
    if(y+h>(int)boot->height)h=(int)boot->height-y;
    uint32_t r=(color>>16)&255,g=(color>>8)&255,b=color&255;
    uint32_t native=boot->pixel_format==0?(b<<16)|(g<<8)|r:(r<<16)|(g<<8)|b;
    volatile uint32_t *fb=(volatile uint32_t*)(uintptr_t)boot->framebuffer;
    for(int yy=y;yy<y+h;yy++){
        volatile uint32_t *line=fb+(size_t)yy*boot->pitch+x;
        for(int xx=0;xx<w;xx++)line[xx]=native;
    }
}
static void text(int x,int y,const char*s,uint32_t color,int scale){
    int start=x;
    for(;*s;s++){
        if(*s=='\n'){y+=10*scale;x=start;continue;}
        const uint8_t *g=glyph_for(*s);
        for(int row=0;row<7;row++)for(int col=0;col<5;col++)if((g[row]>>(4-col))&1)
            rect(x+col*scale,y+row*scale,scale,scale,color);
        x+=6*scale;
        if(x>(int)boot->width-5*scale)return;
    }
}
static void text_number(int x,int y,const char*label,uint64_t number,const char*unit,uint32_t color){
    char buf[96],*p=append(buf,label);p=uint_to_str(p,number);append(p,unit);text(x,y,buf,color,2);
}
static void terminal_line(const char*s){
    char *dst=term_lines[term_next%16];
    unsigned n=0;while(s[n]&&n<95){dst[n]=s[n];n++;}dst[n]=0;
    term_next++;repaint=1;
    serial_str(s);serial_str("\r\n");
}
static void terminal_launch(void){
    terminal_line("ASTER COMMAND SHELL 0.1");
    terminal_line("TYPE HELP FOR AVAILABLE COMMANDS.");
}
static char *skip_spaces(char*s){while(*s==' ')s++;return s;}
static void command(char *line){
    char *p=skip_spaces(line),*args=p;
    while(*args&&*args!=' ')args++;
    if(*args){*args++=0;args=skip_spaces(args);}
    if(!*p)return;
    if(equals(p,"help")){
        terminal_line("HELP LS CAT WRITE RM MEM ALLOC TICKS CLEAR ABOUT");
    }else if(equals(p,"ls")){
        for(int i=0;i<RAMFS_FILES;i++)if(fs.files[i].used)terminal_line(fs.files[i].name);
    }else if(equals(p,"cat")){
        RamFile*f=ramfs_get(&fs,args);
        if(f)terminal_line(f->data);else terminal_line("FILE NOT FOUND");
    }else if(equals(p,"write")){
        char *data=args;while(*data&&*data!=' ')data++;
        if(*data){*data++=0;data=skip_spaces(data);}
        if(!*args||!*data)terminal_line("USAGE: WRITE NAME.TXT MESSAGE");
        else if(ramfs_write(&fs,args,data)<0)terminal_line("WRITE ERROR: BAD NAME OR NO SPACE");
        else terminal_line("FILE WRITTEN (VOLATILE)");
    }else if(equals(p,"rm")){
        terminal_line(ramfs_remove(&fs,args)==0?"FILE REMOVED":"FILE NOT FOUND");
    }else if(equals(p,"mem")){
        char buf[96],*s=append(buf,"FREE CONVENTIONAL MIB: ");s=uint_to_str(s,conventional_mib);terminal_line(buf);
    }else if(equals(p,"alloc")){
        void *page=physical_alloc_page();
        if(page){char buf[96],*s=append(buf,"ALLOCATED FRAME ");hex_to_str(s,(uint64_t)(uintptr_t)page);terminal_line(buf);}
        else terminal_line("OUT OF CONVENTIONAL MEMORY");
    }else if(equals(p,"ticks")){
        char buf[96],*s=append(buf,"PIT TICKS: ");uint_to_str(s,ticks);terminal_line(buf);
    }else if(equals(p,"clear")){
        term_next=0;for(int i=0;i<16;i++)term_lines[i][0]=0;
    }else if(equals(p,"about"))terminal_line("ASTER OS 0.1, INDEPENDENT X86-64 KERNEL");
    else terminal_line("UNKNOWN COMMAND. TYPE HELP.");
}
static void handle_character(char c){
    if(c=='\b'){
        if(screen==4&&input_len){input[--input_len]=0;repaint=1;}
        return;
    }
    if(screen!=4)return;
    if(c=='\n'){
        char buf[96],*p=append(buf,"> ");append(p,input);terminal_line(buf);
        command(input);input_len=0;input[0]=0;repaint=1;
    }else if(c>=32&&c<127&&input_len<sizeof(input)-1){
        input[input_len++]=c;input[input_len]=0;repaint=1;
    }
}
static const char unshifted[128]={
    [0x02]='1',[0x03]='2',[0x04]='3',[0x05]='4',[0x06]='5',[0x07]='6',[0x08]='7',[0x09]='8',[0x0a]='9',[0x0b]='0',
    [0x0c]='-',[0x0d]='=',[0x10]='q',[0x11]='w',[0x12]='e',[0x13]='r',[0x14]='t',[0x15]='y',[0x16]='u',[0x17]='i',[0x18]='o',[0x19]='p',
    [0x1a]='[',[0x1b]=']',[0x1e]='a',[0x1f]='s',[0x20]='d',[0x21]='f',[0x22]='g',[0x23]='h',[0x24]='j',[0x25]='k',[0x26]='l',
    [0x27]=';',[0x28]='\'',[0x29]='`',[0x2b]='\\',[0x2c]='z',[0x2d]='x',[0x2e]='c',[0x2f]='v',[0x30]='b',[0x31]='n',[0x32]='m',
    [0x33]=',',[0x34]='.',[0x35]='/',[0x39]=' '
};
static void process_scan(uint8_t scan){
    if(scan==0x2a||scan==0x36){shifted=1;return;}
    if(scan==0xaa||scan==0xb6){shifted=0;return;}
    if(scan&0x80)return;
    if(scan==0x0e){handle_character('\b');return;}
    if(scan==0x1c){handle_character('\n');return;}
    if(scan>=0x02&&scan<=0x05&&screen!=4){screen=(uint8_t)(scan-0x02);repaint=1;return;}
    if(scan==0x06&&screen!=4){screen=4;repaint=1;return;}
    if(scan==0x3b){screen=0;repaint=1;return;} /* F1: home from terminal */
    if(screen==3&&scan==0x1e){accent_is_teal=!accent_is_teal;repaint=1;return;}
    if(scan<128){
        char c=unshifted[scan];
        if(c>='a'&&c<='z'&&shifted)c=(char)(c-32);
        handle_character(c);
    }
}

struct __attribute__((packed)) IDTEntry {uint16_t offset_lo,selector;uint8_t ist,attributes;uint16_t offset_mid;uint32_t offset_hi,reserved;};
struct __attribute__((packed)) IDTPointer {uint16_t size;uint64_t base;};
static struct IDTEntry idt[256];
#define DECLARE_ISR(n) extern void isr##n(void)
DECLARE_ISR(0);DECLARE_ISR(1);DECLARE_ISR(2);DECLARE_ISR(3);DECLARE_ISR(4);DECLARE_ISR(5);DECLARE_ISR(6);DECLARE_ISR(7);
DECLARE_ISR(8);DECLARE_ISR(9);DECLARE_ISR(10);DECLARE_ISR(11);DECLARE_ISR(12);DECLARE_ISR(13);DECLARE_ISR(14);DECLARE_ISR(15);
DECLARE_ISR(16);DECLARE_ISR(17);DECLARE_ISR(18);DECLARE_ISR(19);DECLARE_ISR(20);DECLARE_ISR(21);DECLARE_ISR(22);DECLARE_ISR(23);
DECLARE_ISR(24);DECLARE_ISR(25);DECLARE_ISR(26);DECLARE_ISR(27);DECLARE_ISR(28);DECLARE_ISR(29);DECLARE_ISR(30);DECLARE_ISR(31);
DECLARE_ISR(32);DECLARE_ISR(33);
static void idt_register(int vector,void (*fn)(void)){
    uintptr_t f=(uintptr_t)fn;
    uint16_t cs;__asm__ volatile("mov %%cs,%0":"=r"(cs));
    idt[vector].offset_lo=f&65535;idt[vector].selector=cs;idt[vector].ist=0;
    idt[vector].attributes=0x8e;idt[vector].offset_mid=(f>>16)&65535;
    idt[vector].offset_hi=(uint32_t)(f>>32);idt[vector].reserved=0;
}
static void init_interrupts(void){
    void (*handlers[34])(void)={isr0,isr1,isr2,isr3,isr4,isr5,isr6,isr7,isr8,isr9,isr10,isr11,
        isr12,isr13,isr14,isr15,isr16,isr17,isr18,isr19,isr20,isr21,isr22,isr23,isr24,
        isr25,isr26,isr27,isr28,isr29,isr30,isr31,isr32,isr33};
    for(int i=0;i<34;i++)idt_register(i,handlers[i]);
    struct IDTPointer ptr={sizeof(idt)-1,(uint64_t)(uintptr_t)idt};
    __asm__ volatile("lidt %0"::"m"(ptr));
    outb(0x20,0x11);io_wait();outb(0xa0,0x11);io_wait();
    outb(0x21,0x20);io_wait();outb(0xa1,0x28);io_wait();
    outb(0x21,4);io_wait();outb(0xa1,2);io_wait();
    outb(0x21,1);io_wait();outb(0xa1,1);io_wait();
    outb(0x21,0xfc);outb(0xa1,0xff);
    /* PIT channel 0 / mode 3 / 100 Hz. */
    outb(0x43,0x36);uint16_t divisor=11932;
    outb(0x40,divisor&255);outb(0x40,(divisor>>8)&255);
}
void interrupt_dispatch(uint64_t *r){
    uint64_t vector=r[15];
    if(vector==32){ticks++;if(ticks%100==0)repaint=1;outb(0x20,0x20);return;}
    if(vector==33){
        uint8_t code=inb(0x60);
        uint32_t next=(scan_w+1)&255;if(next!=scan_r){scans[scan_w]=code;scan_w=next;}
        outb(0x20,0x20);return;
    }
    if(vector<32){
        serial_str("ASTER KERNEL PANIC: CPU EXCEPTION\r\n");
        rect(0,0,boot->width,boot->height,COLOR(78,22,41));
        text(30,30,"KERNEL PANIC",WHITE,3);
        text_number(30,100,"EXCEPTION VECTOR: ",vector,"",WHITE);
        text_number(30,140,"ERROR CODE: ",r[16],"",WHITE);
        __asm__ volatile("cli");for(;;)__asm__ volatile("hlt");
    }
}
static void draw_shell(void){
    int w=(int)boot->width,h=(int)boot->height;
    rect(0,0,w,h,NAVY);
    rect(0,0,w,58,COLOR(18,26,43));
    rect(22,16,27,27,accent());rect(29,23,13,13,NAVY);
    text(65,21,"ASTER OS",WHITE,2);
    text(w-208,24,"DEVELOPER 0.1",MUTED,1);
    rect(0,58,170,h-58,COLOR(16,24,40));
    const char *labels[]={"1 HOME","2 FILES","3 SYSTEM","4 SETTINGS","5 TERMINAL"};
    for(int i=0;i<5;i++){
        int y=105+i*65;
        if(screen==i){rect(12,y-13,145,45,PANEL2);rect(12,y-13,4,45,accent());}
        text(28,y,labels[i],screen==i?WHITE:MUTED,1);
    }
    text(23,h-60,"F1 HOME",MUTED,1);
    text(23,h-42,"PS/2 INPUT",MUTED,1);
    rect(170,h-43,w-170,43,COLOR(18,26,43));
    text(194,h-28,"NATIVE X86-64  |  UEFI HANDOFF  |  PIT + IRQ",MUTED,1);
    text_number(w-156,h-28,"UP ",ticks/100,"S",accent());
}
static void screen_home(void){
    int w=(int)boot->width;
    text(204,94,"WELCOME TO ASTER",WHITE,3);
    text(206,143,"A SMALL, INDEPENDENT OPERATING SYSTEM",MUTED,1);
    rect(204,192,w-245,164,PANEL);
    rect(204,192,5,164,accent());
    text(230,216,"EARLY KERNEL PREVIEW",accent(),2);
    text(230,263,"A FREESTANDING 64-BIT KERNEL.",WHITE,1);
    text(230,284,"FRAMEBUFFER UI, INTERRUPTS AND RAMFS.",WHITE,1);
    text(230,306,"NOT YET A COMPLETE DESKTOP OS.",MUTED,1);
    rect(204,383,w-245,105,PANEL);
    text(226,403,"EXPLORE",WHITE,2);
    text(226,446,"PRESS 2-5 FOR PAGES. F1 RETURNS HOME.",MUTED,1);
}
static void screen_files(void){
    text(205,96,"IN-MEMORY FILES",WHITE,2);
    text(205,129,"RAMFS DATA IS LOST WHEN THE VM RESTARTS",MUTED,1);
    int y=178;
    for(int i=0;i<RAMFS_FILES;i++)if(fs.files[i].used&&y<(int)boot->height-120){
        rect(205,y,boot->width-247,53,PANEL);text(221,y+10,fs.files[i].name,WHITE,2);
        text_number((int)boot->width-170,y+15,"BYTES ",fs.files[i].size,"",MUTED);
        y+=63;
    }
    text(210,(int)boot->height-84,"EDIT WITH TERMINAL: WRITE NAME.TXT MESSAGE",accent(),1);
}
static void screen_system(void){
    text(205,97,"SYSTEM INFORMATION",WHITE,2);
    rect(205,158,boot->width-247,260,PANEL);
    text(226,184,"PLATFORM: X86-64  |  UEFI GOP",accent(),1);
    text_number(226,219,"DISPLAY WIDTH:  ",boot->width," PX",WHITE);
    text_number(226,251,"DISPLAY HEIGHT: ",boot->height," PX",WHITE);
    text_number(226,283,"FREE RAM:       ",conventional_mib," MIB",WHITE);
    text_number(226,315,"FRAMES ALLOC:   ",allocated_frames,"",WHITE);
    text_number(226,347,"KERNEL SIZE:    ",boot->kernel_load_bytes/1024," KIB",WHITE);
    text_number(226,379,"PIT TICKS:      ",ticks,"",WHITE);
    text(210,452,"ACPI RSDP DISCOVERY ENABLED. USB/NVME NOT YET.",MUTED,1);
}
static void screen_settings(void){
    text(205,97,"APPEARANCE SETTINGS",WHITE,2);
    rect(205,164,boot->width-250,136,PANEL);
    text(228,188,"ACCENT COLOR",WHITE,2);
    text(228,222,"PRESS A TO TOGGLE COLOR",MUTED,1);
    rect(228,258,110,12,accent());
    text(205,340,"KEYBOARD: LEGACY PS/2 (SET 1)",MUTED,1);
    text(205,367,"DISPLAY: UEFI GOP FRAMEBUFFER",MUTED,1);
}
static void screen_terminal(void){
    int w=(int)boot->width,h=(int)boot->height;
    text(205,90,"ASTER TERMINAL",WHITE,2);
    rect(205,127,w-249,h-207,COLOR(7,13,24));
    int line_h=18,max_lines=(h-246)/line_h;if(max_lines>14)max_lines=14;
    unsigned first=term_next>(unsigned)max_lines?term_next-(unsigned)max_lines:0;
    int yy=149;
    for(unsigned i=first;i<term_next;i++){
        text(218,yy,term_lines[i%16],MUTED,1);yy+=line_h;
    }
    rect(214,h-120,w-272,30,PANEL2);
    char cursor[100],*p=append(cursor,"> ");p=append(p,input);append(p,"_");
    text(224,h-111,cursor,accent(),1);
    text(212,h-68,"F1 HOME  |  HELP  LS  CAT  WRITE  RM  MEM",MUTED,1);
}
static void draw(void){
    draw_shell();
    switch(screen){
        case 0:screen_home();break;
        case 1:screen_files();break;
        case 2:screen_system();break;
        case 3:screen_settings();break;
        case 4:screen_terminal();break;
    }
}
void kernel_main(AsterBootInfo *b){
    boot=b;
    if(b->magic!=ASTER_BOOT_MAGIC||b->version!=ASTER_BOOT_VERSION||b->size<sizeof(*b)||!b->framebuffer||
       b->width<640||b->height<480||b->pitch<b->width||b->pixel_format>1){
        for(;;)__asm__ volatile("hlt");
    }
    serial_init();serial_str("\r\nAster OS 0.1: entered native kernel\r\n");
    physical_init();ramfs_init(&fs);
    if(!kalloc(128))serial_str("Heap initialization failed\r\n");
    terminal_launch();init_interrupts();draw();repaint=0;
    serial_str("IDT, PIC, PIT, PS/2 ready; interrupts enabled\r\n");
    __asm__ volatile("sti":::"memory");
    for(;;){
        while(scan_r!=scan_w){
            uint8_t code=scans[scan_r];scan_r=(scan_r+1)&255;process_scan(code);
        }
        if(repaint){repaint=0;draw();}
        __asm__ volatile("hlt");
    }
}
