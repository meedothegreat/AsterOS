# Known issues and unsupported features

## Critical / blockers

- **No VM boot executed:** QEMU, VirtualBox and OVMF are not installed in the creation environment. The ISO passes format and embedded-file checks, not firmware execution checks.
- **No installer or installed image:** Cannot create partitions, install to a VM disk or boot from it.
- **No persistent files:** RAMFS operations are real but all data is lost at restart.
- **No general-purpose process model:** Shell and screens execute in kernel context; no ring 3, system calls, or multitasking.
- **No native modern laptop device drivers:** GPU, NVMe, USB, Wi-Fi, Bluetooth, audio, battery, webcam and sleep are unsupported.
- **No Windows application support:** No PE application loader, NT/Win32 APIs, Wine, Proton or DirectX translation.
- **No secure-boot signature:** Image will not boot under firmware enforcing Secure Boot. Disable only in a disposable VM for testing; never turn off host platform security to use this experiment.

## Limitations and risks

- No paging setup or isolation; relies on UEFI's inherited identity mapping.
- Legacy 8259 PIC/PIT and PS/2 keyboard may not be present in a given VM or laptop. Keyboard processing may not work on physical hardware.
- The interrupt subsystem currently initializes handlers for vectors 0–33 only; other external interrupt sources are masked, not supported.
- No APIC, USB HID, thread scheduler, locking, filesystem write-back, or authentication.
- A simple buffer-limited shell, hard-coded US keyboard layout, fixed-size terminal history, uppercase-only drawn glyphs.
- Only UEFI GOP pixel formats RGB8/BGR8 and screen >= 640×480; no pixel-mask framebuffer format.
- Memory reporting estimates EfiConventionalMemory present after UEFI boot services. Not a complete physical RAM inventory.
- UEFI loader can reject valid but unsupported ELF relocations or unusual firmware memory maps.
- No attempt to run or even partition the host computer. **Do not treat v0.1 as ready to install on the ASUS laptop.**

## Suggested VM diagnostic procedure

- Capture a VM screenshot, firmware boot log, and UART serial COM1 log.
- In QEMU with OVMF when available, add `-serial file:aster-serial.log` for reliable early kernel output.
- If firmware does not recognize the ISO, inspect EFI boot catalog and virtual optical drive setup. Run `make checks` locally.
- If UEFI prints `KERNEL.ELF missing`, check embedded FAT root directory and boot file path.
- If the UEFI loader prints `Invalid or unsupported kernel ELF`, inspect dynamic relative relocations with `readelf -r`.
- If boot leaves firmware but never shows the UI, inspect serial and kernel panic output. It may be a framebuffer mapping, IDT or firmware compatibility issue.
