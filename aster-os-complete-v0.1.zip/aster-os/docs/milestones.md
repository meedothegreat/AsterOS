# Milestones and acceptance criteria — Aster OS

| Stage | Acceptance criterion | Status 2026-10-26 |
| --- | --- | --- |
| 1. Architecture/repository | Modular monolithic design, source tree, reproducible build, tests, known issues | **Implemented** |
| 2. Bootable kernel | UEFI ISO, ELF loading, exception/PIT, console, real VM boot evidence | **Partly implemented; VM boot not tested** |
| 3. Core kernel services | Own paging, isolation, preemptive scheduler, syscalls, IPC, VFS, storage | **Not implemented** (initial frame allocator and interrupts only) |
| 4. User space | Separated ring-3 userspace, loader, system services, utilities | **Not implemented** (built-in kernel command shell only) |
| 5. Graphics/desktop | Window manager, input, desktop, settings, functional file manager | **Not implemented** (framebuffer navigation preview only) |
| 6. Installer | Confirmed partitioning, formatting, install and reboot from disk | **Not implemented** |
| 7. Hardware/VirtualBox | IDs, drivers, compatible virtual devices, boot/installation tests | **Not verified** (GOP and PS/2 are initial targets) |
| 8. Windows compatibility | Wine/Win32 integration and measured .exe/.msi test suite | **Not implemented** |
| 9. Security/polish | Memory isolation, authentication, signed updates, recovery, accessibility | **Not implemented** |
| 10. Release | Verified bootable + installable VM ISO, disk image, hardware report | **Not achieved** (development ISO created and structurally verified) |

Aster OS v0.1 is **not** a complete operating system by the original specification. It is a coherent starting milestone. A working ISO file is not equivalent to a boot-tested, installable ISO. Runtime tests should be added before declaring stage 2 finished.
