#include "efi.h"
#include "elf.h"
#include "boot_protocol.h"

/* Pure UEFI PE32+ bootstrap. No host OS, libc, or third-party bootloader. */
static EFI_SYSTEM_TABLE *sys;
static EFI_BOOT_SERVICES *bs;
static void say(const CHAR16 *msg) {sys->ConOut->OutputString(sys->ConOut,msg);}
static void copy_bytes(void *dst,const void *src,UINTN n) {uint8_t*d=dst;const uint8_t*s=src;for(UINTN i=0;i<n;i++) d[i]=s[i];}
static void zero_bytes(void *dst,UINTN n) {uint8_t*d=dst;for(UINTN i=0;i<n;i++) d[i]=0;}
static int fits(uint64_t offset,uint64_t size,uint64_t limit){return offset<=limit && size<=limit-offset;}
static void halt(const CHAR16 *msg){say(msg);for(;;)__asm__ volatile("hlt");}
static int load_kernel(const uint8_t *file,uint64_t file_len,uint64_t *entry,uint64_t *addr,uint64_t *extent){
    if(file_len<sizeof(Elf64_Ehdr))return 0;
    const Elf64_Ehdr *e=(const Elf64_Ehdr*)file;
    if(e->ident[0]!=127||e->ident[1]!='E'||e->ident[2]!='L'||e->ident[3]!='F'||e->ident[4]!=2||e->ident[5]!=1||e->type!=ET_DYN||e->machine!=EM_X86_64)return 0;
    if(e->phentsize!=sizeof(Elf64_Phdr)||e->phnum==0||e->phnum>64||!fits(e->phoff,(uint64_t)e->phnum*sizeof(Elf64_Phdr),file_len))return 0;
    const Elf64_Phdr *ph=(const Elf64_Phdr*)(file+e->phoff);
    uint64_t lower=UINT64_MAX,upper=0;
    for(uint32_t i=0;i<e->phnum;i++)if(ph[i].type==PT_LOAD){
        if(!fits(ph[i].offset,ph[i].filesz,file_len)||ph[i].memsz<ph[i].filesz||ph[i].vaddr+ph[i].memsz<ph[i].vaddr)return 0;
        if(ph[i].vaddr<lower)lower=ph[i].vaddr;
        if(ph[i].vaddr+ph[i].memsz>upper)upper=ph[i].vaddr+ph[i].memsz;
    }
    if(lower==UINT64_MAX||upper<=lower||upper-lower>16*1024*1024ULL||lower%4096)return 0;
    uint64_t bytes=(upper-lower+4095)&~4095ULL;
    EFI_PHYSICAL_ADDRESS mem=0;
    if(EFI_ERROR(bs->AllocatePages(AllocateAnyPages,EfiLoaderData,bytes/4096,&mem)))return 0;
    zero_bytes((void*)(UINTN)mem,bytes);
    for(uint32_t i=0;i<e->phnum;i++)if(ph[i].type==PT_LOAD){
        copy_bytes((void*)(UINTN)(mem+ph[i].vaddr-lower),file+ph[i].offset,(UINTN)ph[i].filesz);
    }
    /* ET_DYN base relocations: support the statically linked R_X86_64_RELATIVE ABI. */
    uint64_t rela_vaddr=0,rela_len=0,rela_ent=sizeof(Elf64_Rela);
    for(uint32_t i=0;i<e->phnum;i++)if(ph[i].type==PT_DYNAMIC){
        if(ph[i].vaddr<lower||!fits(ph[i].vaddr-lower,ph[i].memsz,bytes))return 0;
        Elf64_Dyn *dyn=(Elf64_Dyn*)(UINTN)(mem+ph[i].vaddr-lower);
        for(uint64_t j=0;j<ph[i].memsz/sizeof(Elf64_Dyn);j++){
            if(dyn[j].tag==DT_NULL)break;
            if(dyn[j].tag==DT_RELA)rela_vaddr=dyn[j].val;
            if(dyn[j].tag==DT_RELASZ)rela_len=dyn[j].val;
            if(dyn[j].tag==DT_RELAENT)rela_ent=dyn[j].val;
        }
    }
    if(rela_len){
        if(rela_ent!=sizeof(Elf64_Rela)||!rela_vaddr||rela_vaddr<lower||!fits(rela_vaddr-lower,rela_len,bytes)||rela_len%rela_ent)return 0;
        Elf64_Rela *relas=(Elf64_Rela*)(UINTN)(mem+rela_vaddr-lower);
        for(uint64_t i=0;i<rela_len/rela_ent;i++){
            if((uint32_t)relas[i].info!=R_X86_64_RELATIVE||relas[i].offset<lower||!fits(relas[i].offset-lower,8,bytes))return 0;
            *(uint64_t*)(UINTN)(mem+relas[i].offset-lower)=(mem-lower)+(uint64_t)relas[i].addend;
        }
    }
    if(e->entry<lower||!fits(e->entry-lower,1,bytes))return 0;
    *entry=(mem-lower)+e->entry; *addr=mem; *extent=bytes;return 1;
}
EFI_STATUS efi_main(EFI_HANDLE image,EFI_SYSTEM_TABLE *system){
    sys=system;bs=system->BootServices;
    say(u"\r\nAster OS - EFI loader 0.1\r\n");
    EFI_LOADED_IMAGE_PROTOCOL *loaded=0;
    if(EFI_ERROR(bs->HandleProtocol(image,&EFI_LOADED_IMAGE_GUID,(void**)&loaded)))halt(u"Cannot find loaded-image protocol\r\n");
    EFI_SIMPLE_FILE_SYSTEM_PROTOCOL *fs=0;
    if(EFI_ERROR(bs->HandleProtocol(loaded->DeviceHandle,&EFI_SIMPLE_FS_GUID,(void**)&fs)))halt(u"Cannot access EFI volume\r\n");
    EFI_FILE_PROTOCOL *root=0,*f=0;
    if(EFI_ERROR(fs->OpenVolume(fs,&root)))halt(u"Cannot open EFI volume\r\n");
    if(EFI_ERROR(root->Open(root,&f,u"\\KERNEL.ELF",EFI_FILE_MODE_READ,0)))halt(u"KERNEL.ELF missing\r\n");
    uint8_t *kernel_file=0;
    const UINTN max_kernel_file=4*1024*1024;
    if(EFI_ERROR(bs->AllocatePool(EfiLoaderData,max_kernel_file,(void**)&kernel_file)))halt(u"Insufficient loader memory\r\n");
    UINTN received=max_kernel_file;
    if(EFI_ERROR(f->Read(f,&received,kernel_file)))halt(u"Kernel read failed\r\n");
    f->Close(f);root->Close(root);
    uint64_t kernel_entry=0,kernel_base=0,kernel_size=0;
    if(!load_kernel(kernel_file,received,&kernel_entry,&kernel_base,&kernel_size))halt(u"Invalid or unsupported kernel ELF\r\n");
    bs->FreePool(kernel_file);
    EFI_GRAPHICS_OUTPUT_PROTOCOL *gop=0;
    if(EFI_ERROR(bs->LocateProtocol(&EFI_GOP_GUID,0,(void**)&gop)))halt(u"UEFI GOP framebuffer not found\r\n");
    /* Prefer 1024x768, then 800x600; retain current mode if no supported match. */
    uint32_t best=gop->Mode->Mode;
    for(uint32_t i=0;i<gop->Mode->MaxMode;i++){
        UINTN info_size=0;EFI_GRAPHICS_OUTPUT_MODE_INFORMATION *info=0;
        if(EFI_ERROR(gop->QueryMode(gop,i,&info_size,&info)))continue;
        if((info->HorizontalResolution==1024&&info->VerticalResolution==768)||
            (info->HorizontalResolution==800&&info->VerticalResolution==600&&best==gop->Mode->Mode))best=i;
        bs->FreePool(info);
    }
    if(best!=gop->Mode->Mode)gop->SetMode(gop,best);
    EFI_GRAPHICS_OUTPUT_MODE_INFORMATION *gi=gop->Mode->Info;
    if(gi->PixelFormat>1||gi->HorizontalResolution<640||gi->VerticalResolution<480)halt(u"No supported RGB/BGR GOP mode\r\n");
    AsterBootInfo *bi=0;
    if(EFI_ERROR(bs->AllocatePool(EfiLoaderData,sizeof(AsterBootInfo),(void**)&bi)))halt(u"Boot information allocation failed\r\n");
    zero_bytes(bi,sizeof(*bi));
    bi->magic=ASTER_BOOT_MAGIC;bi->version=ASTER_BOOT_VERSION;bi->size=sizeof(*bi);
    bi->framebuffer=gop->Mode->FrameBufferBase;bi->width=gi->HorizontalResolution;bi->height=gi->VerticalResolution;
    bi->pitch=gi->PixelsPerScanLine;bi->pixel_format=gi->PixelFormat;
    bi->kernel_load_base=kernel_base;bi->kernel_load_bytes=kernel_size;
    for(UINTN i=0;i<sys->NumberOfTableEntries;i++){
        const EFI_GUID *g=&sys->ConfigurationTable[i].VendorGuid;
        const uint8_t *a=(const uint8_t*)g,*b=(const uint8_t*)&EFI_ACPI_20_GUID;
        int eq=1;for(int j=0;j<16;j++)if(a[j]!=b[j])eq=0;
        if(eq)bi->rsdp=(uint64_t)(UINTN)sys->ConfigurationTable[i].VendorTable;
    }
    /* After successful ExitBootServices, no EFI calls or allocations are permitted. */
    UINTN mmap_cap=128*1024,mmap_size,key=0,desc_size=0;uint32_t desc_ver=0;
    void *mmap=0;
    if(EFI_ERROR(bs->AllocatePool(EfiLoaderData,mmap_cap,&mmap)))halt(u"Memory-map allocation failed\r\n");
    say(u"Kernel loaded; exiting UEFI boot services.\r\n");
    EFI_STATUS status=EFI_INVALID_PARAMETER;
    for(int tries=0;tries<5;tries++){
        mmap_size=mmap_cap;
        status=bs->GetMemoryMap(&mmap_size,mmap,&key,&desc_size,&desc_ver);
        if(status==EFI_BUFFER_TOO_SMALL)halt(u"Memory map exceeded reserved capacity\r\n");
        if(EFI_ERROR(status))halt(u"GetMemoryMap failed\r\n");
        bi->memory_map=(uint64_t)(UINTN)mmap;
        bi->memory_map_size=mmap_size;
        bi->memory_descriptor_size=desc_size;
        status=bs->ExitBootServices(image,key);
        if(status==EFI_SUCCESS)break;
        if(status!=EFI_INVALID_PARAMETER)halt(u"ExitBootServices failed\r\n");
    }
    if(status!=EFI_SUCCESS)halt(u"Could not exit boot services\r\n");
    __asm__ volatile("cli":::"memory");
    typedef void (__attribute__((sysv_abi)) *AsterKernelEntry)(AsterBootInfo*);
    AsterKernelEntry entry=(AsterKernelEntry)(UINTN)kernel_entry;
    entry(bi);
    for(;;)__asm__ volatile("hlt");
}
/* Force a PE/COFF base relocation block for firmware that refuses to load
   a relocatable image without a relocation directory. */
__attribute__((used)) static void *const pe_relocation_anchor = (void*)&efi_main;
